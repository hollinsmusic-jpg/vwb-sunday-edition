// ═══════════════════════════════════════════════════════════════
//  Virtual Worship Band — UI Rendering
//  Tab navigation, stem/section/mixer render, audio routing,
//  mini scrub bar, panic, and keyboard shortcuts.
//  Depends on: state.js, audio-engine.js, stems.js
// ═══════════════════════════════════════════════════════════════

// ── Section Jump Quantize Setting ─────────────────────────────
// Controls how far ahead a section jump is queued before firing.
// 'immediate' | 'halfbar' | '1bar' (default) | '2bar'
let sectionJumpQuantize = '1bar';

// ── Fade Out Duration Setting ──────────────────────────────────
let vwbFadeDuration = 4;

function setFadeDuration(val) {
  vwbFadeDuration = parseInt(val) || 4;
  _saveAppSettings();
  const sel = document.getElementById('fadeDurationSel');
  if (sel) sel.value = vwbFadeDuration;
  showNotification('Fade: ' + vwbFadeDuration + 's');
}

function setSectionJumpQuantize(val) {
  sectionJumpQuantize = val;
  // Persist with settings
  _saveAppSettings();
  // Update the UI selector
  const sel = document.getElementById('sectionJumpQuantizeSel');
  if (sel) sel.value = val;
  showNotification('Section jump: ' + _quantizeLabel(val));
}

function _quantizeLabel(val) {
  return { immediate: 'Immediate', halfbar: '½ Measure', '1bar': '1 Measure (default)', '2bar': '2 Measures' }[val] || val;
}

async function _saveAppSettings() {
  if (!window.vwb) return;
  try {
    // Merge MIDI output port pref if set
    const existing = await window.vwb.loadSettings().catch(() => null);
    const midiOutputPort = (existing && existing.success && existing.data && existing.data.midiOutputPort)
      ? existing.data.midiOutputPort : undefined;
    await window.vwb.saveSettings({
      rMode, crossfadeMode, crossfadeDuration, sectionJumpQuantize, vwbFadeDuration,
      ...(midiOutputPort !== undefined ? { midiOutputPort } : {})
    });
  } catch(e) {}
}

async function loadAppSettings() {
  if (!window.vwb) return;
  try {
    const res = await window.vwb.loadSettings();
    if (res && res.success && res.data) {
      const d = res.data;
      if (d.rMode)               setRoute(d.rMode, true);
      if (d.crossfadeMode)       crossfadeMode    = d.crossfadeMode;
      if (d.crossfadeDuration)   crossfadeDuration = d.crossfadeDuration;
      if (d.sectionJumpQuantize) sectionJumpQuantize = d.sectionJumpQuantize;
      if (d.vwbFadeDuration)     vwbFadeDuration     = d.vwbFadeDuration;
    }
  } catch(e) {}
}

// ── Armor Bearer Panel Toggle ──────────────────────────────────
function toggleAbPanel() {
  const body  = document.getElementById('abPanelBody');
  const arrow = document.getElementById('abToggleArrow');
  const hint  = document.getElementById('abPanelHint');
  if (!body) return;
  const open = body.style.display === 'none';
  body.style.display  = open ? 'block' : 'none';
  if (arrow) arrow.style.transform = open ? 'rotate(90deg)' : 'rotate(0deg)';
  if (hint)  hint.textContent      = open ? 'Click to collapse' : 'Click to expand';
  if (open && typeof renderArmorBearerSetup === 'function') renderArmorBearerSetup();
}

function goView(v) {
  document.querySelectorAll('.view').forEach(e => e.classList.remove('active'));
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
  const viewEl = document.getElementById('view-' + v);
  if (viewEl) viewEl.classList.add('active');
  document.querySelectorAll('.nav-tab').forEach(t => {
    if (t.getAttribute('onclick') === "goView('" + v + "')") t.classList.add('active');
  });
  if (v === 'perform')     refreshPerfView();
  if (v === 'setlist')     renderSetlist();
  if (v === 'setup')       initMiniBeats();
  if (v === 'servicepack') { if (typeof renderServicePackBrowser === 'function') renderServicePackBrowser(); }
  if (v === 'settings') {
    renderRouting();
    loadAppSettings();
    if (typeof renderMrcGrid === 'function') renderMrcGrid();
    if (typeof refreshMrcInputs === 'function') refreshMrcInputs();
  }
  if (v === 'service') {
    renderSvcCues();
    const tab = document.getElementById('svcNavTab');
    if (tab) tab.classList.add('active');
  }
}

// ── Theme / Appearance ─────────────────────────────────────────

function setTheme(theme) {
  document.body.classList.toggle('light-mode', theme === 'light');
  // Update theme card selection
  const dark  = document.getElementById('themeCardDark');
  const light = document.getElementById('themeCardLight');
  if (dark)  dark.classList.toggle('selected',  theme === 'dark');
  if (light) light.classList.toggle('selected', theme === 'light');
  // Persist preference
  try { localStorage.setItem('vwb_theme', theme); } catch(e) {}
}

function loadTheme() {
  try {
    const saved = localStorage.getItem('vwb_theme') || 'dark';
    setTheme(saved);
  } catch(e) { setTheme('dark'); }
}



function renderStems() {
  const g = document.getElementById('stemsGrid');
  g.innerHTML = '';
  SK.forEach(k => {
    const ld = !!S[k].buf;
    g.innerHTML +=
      '<div class="stem-slot ' + (ld ? 'loaded' : '') + '" onclick="if(!event.target.classList.contains(\'s-rm\'))pickAndLoadStem(\'' + k + '\')">' +
      '<button class="s-rm" onclick="event.stopPropagation();rmStem(\'' + k + '\')">×</button>' +
      '<div class="s-icon">' + SL[k].split(' ')[0] + '</div>' +
      '<div class="s-label">' + SL[k].split(' ').slice(1).join(' ') + '</div>' +
      (ld
        ? '<div class="s-file">' + S[k].fn + '</div><div class="s-status ok">✓ Loaded</div>'
        : '<div class="s-status">Click to load</div>') +
      '</div>';
  });
}

// ── Aux Panel ──────────────────────────────────────────────────

function renderAuxPanel() {
  const c = document.getElementById('auxTracksList');
  if (!c) return;
  c.innerHTML = '';
  if (!auxTracks.length) {
    c.innerHTML = '<p style="font-size:.8rem;color:var(--text-dim);font-style:italic;padding:.5rem 0">No aux tracks loaded yet. Click "+ Add Aux Track" to add drums, strings, pads, etc.</p>';
    return;
  }
  auxTracks.forEach((t, i) => {
    c.innerHTML +=
      '<div class="stem-slot loaded" style="border-color:#f0c040;background:rgba(240,192,64,.05);flex-direction:row;justify-content:flex-start;gap:.75rem;min-height:50px;padding:.6rem 1rem">' +
      '<span style="font-size:1.1rem">🎶</span>' +
      '<span style="font-size:.85rem;font-weight:500;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + t.fn + '">' + t.fn + '</span>' +
      '<div style="display:flex;align-items:center;gap:.4rem"><span style="font-size:.65rem;color:var(--text-dim)">Vol</span><input type="range" min="0" max="100" value="' + t.vol + '" style="-webkit-appearance:none;width:60px;height:3px;border-radius:2px;background:var(--bg-primary)" oninput="setAuxTrackVol(' + i + ',this.value)"></div>' +
      '<span style="font-size:.7rem;color:var(--text-dim);font-family:\'Space Mono\',monospace">' + fmt(t.buf.duration) + '</span>' +
      '<button class="s-rm" style="position:static;display:block" onclick="event.stopPropagation();removeAuxTrack(' + i + ')">×</button>' +
      '</div>';
  });
}

// ── Section Editor ─────────────────────────────────────────────

function renderSections() {
  const l = document.getElementById('secList');
  l.innerHTML = '';
  song.secs.forEach((s, i) => {
    const isNow     = playing && i === curSec;
    const isCustom  = s.type === 'Custom' || !SEC_TYPES.slice(0,-1).includes(s.type);
    const displayType = isCustom ? 'Custom' : s.type;
    const customVal   = isCustom ? (s.customLabel || s.type || '') : '';
    const customDisplay = isCustom ? '' : 'none';
    const opts = SEC_TYPES.map(t => '<option' + (displayType===t?' selected':'') + '>' + t + '</option>').join('');

    const loopFlag = s.loop === true;
    l.innerHTML +=
      '<div class="sec-row' + (isNow ? ' now-playing' : '') + '" data-idx="' + i + '">' +
      '<span class="sec-n">' + (i+1) + '</span>' +
      '<select onchange="onSecTypeChange(this,' + i + ')">' + opts + '</select>' +
      '<div style="display:flex;flex-direction:column;gap:.25rem;flex:1">' +
        '<input type="text" value="' + (s.label||'') + '" placeholder="Optional label" onchange="song.secs[' + i + '].label=this.value">' +
        '<input type="text" class="custom-sec-name" data-idx="' + i + '" value="' + customVal + '" placeholder="Name this section…" style="display:' + customDisplay + ';font-size:.78rem;border-color:var(--gold);color:var(--gold)" onchange="song.secs[' + i + '].customLabel=this.value">' +
      '</div>' +
      '<input type="number" class="m-input" value="' + s.sb + '" min="1" onchange="song.secs[' + i + '].sb=parseInt(this.value)">' +
      '<input type="number" class="m-input" value="' + s.eb + '" min="1" onchange="song.secs[' + i + '].eb=parseInt(this.value)">' +
      '<button title="' + (loopFlag ? 'Loop ON — click to turn off' : 'Loop OFF — click to pre-save loop') + '" onclick="toggleSecLoopFlag(' + i + ')" style="font-size:.85rem;width:28px;height:28px;border-radius:6px;border:1px solid ' + (loopFlag ? 'var(--accent)' : 'var(--border)') + ';background:' + (loopFlag ? 'rgba(64,224,208,.15)' : 'none') + ';color:' + (loopFlag ? 'var(--accent)' : 'var(--text-dim)') + ';cursor:pointer;flex-shrink:0;display:flex;align-items:center;justify-content:center;">🔁</button>' +
      '<button class="btn-rm" onclick="song.secs.splice(' + i + ',1);renderSections();">×</button>' +
      '</div>';
  });
}

function onSecTypeChange(sel, idx) {
  song.secs[idx].type = sel.value;
  const row = sel.closest('.sec-row');
  const customInput = row.querySelector('.custom-sec-name');
  if (sel.value === 'Custom') { customInput.style.display = ''; customInput.focus(); }
  else { customInput.style.display = 'none'; song.secs[idx].customLabel = ''; }
}

function addSec() {
  const last = song.secs.length > 0 ? song.secs[song.secs.length-1].eb : 0;
  song.secs.push({ type:'Verse', label:'', sb:last+1, eb:last+8 });
  renderSections();
}

function initMiniBeats() {
  const c = document.getElementById('mtBeat');
  c.innerHTML = '';
  for (let i = 0; i < bpb(); i++) c.innerHTML += '<div class="mt-bd"></div>';
}

// ── Perform View ───────────────────────────────────────────────

function refreshPerfView() {
  document.getElementById('pTitle').textContent  = song.title || 'Untitled';
  document.getElementById('pTempo').textContent  = (song.tempo || 72) + ' BPM';
  document.getElementById('pTS').textContent     = song.ts || '4/4';
  document.getElementById('pStems').textContent  = stemCount() + ' tracks' + (auxTracks.length > 0 ? ' (' + auxTracks.length + ' aux)' : '');
  document.getElementById('pRoute').textContent  = rMode === 'multi' ? '8-Ch Multi-Out' : 'Stereo';
  document.getElementById('tlTotal').textContent = fmt(getDur());
  const bi = document.getElementById('beatInd');
  if (bi) {
    bi.innerHTML = '';
    for (let i = 0; i < bpb(); i++) bi.innerHTML += '<div class="b-dot"></div>';
  }
  renderMixer();
  updatePerfLoopUI();
  updateLoopBtns();
  // Unified transport refresh
  if (typeof uniRefreshPerfView === 'function') uniRefreshPerfView();
  // Armor Bearer perform panel
  if (typeof renderArmorBearerPerform === 'function') renderArmorBearerPerform();
}

function renderTimeline() {
  const c = document.getElementById('tlSecs');
  c.innerHTML = '';
  const d = getDur();
  if (d <= 0 || !song.secs.length) return;
  song.secs.forEach((s, i) => {
    const st = bar2time(s.sb), et = bar2time(s.eb + 1);
    const wp = ((et - st) / d) * 100;
    const tlLabel = (s.type === 'Custom' && s.customLabel) ? s.customLabel : s.type;
    c.innerHTML += '<div class="tl-sec' + (i===curSec?' on':'') + '" style="width:' + Math.min(wp,100) + '%;position:relative" onclick="event.stopPropagation();queueSection(' + i + ')">' + tlLabel + '</div>';
  });
}

function renderPerfSections() {
  const c = document.getElementById('pSecs');
  c.innerHTML = '';
  song.secs.forEach((s, i) => {
    const a = i === curSec, q = i === qSec;
    const hasLoopFlag = s.loop === true;
    const isLooping   = a && (secLoopOn || hasLoopFlag);
    const loopInd = isLooping
      ? '<span class="sec-loop-indicator on">🔁 LOOPING</span>'
      : (hasLoopFlag ? '<span class="sec-loop-indicator" style="opacity:.45">🔁 preset</span>' : '');
    const secDisplayName = (s.type === 'Custom' && s.customLabel) ? s.customLabel : s.type;
    const loopBtnStyle = 'font-size:.65rem;padding:.15rem .35rem;border-radius:4px;border:1px solid ' +
      (hasLoopFlag ? 'var(--accent)' : 'var(--border)') +
      ';background:' + (hasLoopFlag ? 'rgba(64,224,208,.15)' : 'none') +
      ';color:' + (hasLoopFlag ? 'var(--accent)' : 'var(--text-dim)') +
      ';cursor:pointer;margin-left:auto;flex-shrink:0';
    c.innerHTML +=
      '<div class="p-sec' + (a?' act':'') + (q?' q':'') + '" onclick="queueSection(' + i + ')">' +
      '<span class="s-hk">' + (i+1) + '</span>' +
      '<div class="s-inf"><h4>' + secDisplayName + (s.label ? ' — ' + s.label : '') + '</h4>' +
      '<div class="s-meas">Bars ' + s.sb + ' – ' + s.eb + ' ' + loopInd + '</div></div>' +
      '<button style="' + loopBtnStyle + '" onclick="event.stopPropagation();toggleSecLoopFlag(' + i + ')" title="Toggle pre-saved loop for this section">🔁</button>' +
      '<div class="s-qlbl">NEXT ▶</div>' +
      '</div>';
  });
}

// ── Mixer ──────────────────────────────────────────────────────

function renderMixer() {
  const c = document.getElementById('mixCh');
  c.innerHTML = '';

  SK.forEach(k => {
    if (!S[k].buf) return;
    const chLabel = rMode === 'multi'
      ? (ROUTE_MAP[k].stereo ? (ROUTE_MAP[k].ch[0]+1)+'-'+(ROUTE_MAP[k].ch[1]+1) : ''+(ROUTE_MAP[k].ch[0]+1))
      : '1-2';
    c.innerHTML +=
      '<div class="mix-ch">' +
      '<button class="cb' + (S[k].muted?' mt':'') + '" onclick="toggleMute(\'' + k + '\')">M</button>' +
      '<button class="cb' + (S[k].solo?' sl':'')  + '" onclick="toggleSolo(\'' + k + '\')">S</button>' +
      '<span class="cn" style="color:' + SC[k] + '">' + SL[k].split(' ').slice(1).join(' ') + '</span>' +
      '<input type="range" class="cs" min="0" max="100" value="' + S[k].vol + '" oninput="setVol(\'' + k + '\',this.value);this.parentElement.querySelector(\'.cl\').textContent=this.value+\'%\'">' +
      '<span class="cl">' + S[k].vol + '%</span>' +
      '<span class="co">' + chLabel + '</span>' +
      '</div>';
  });

  if (auxTracks.length > 0) {
    const auxChLabel = rMode === 'multi' ? '6-7' : '1-2';
    c.innerHTML += '<div style="margin-top:.5rem;padding-top:.5rem;border-top:1px solid var(--border)"><div class="mix-title" style="color:#f0c040;margin-bottom:.3rem;font-size:.7rem">🎶 Aux Stems</div></div>';
    c.innerHTML +=
      '<div class="mix-ch" style="border:1px solid rgba(240,192,64,.2);border-radius:8px">' +
      '<button class="cb' + (auxMasterMuted?' mt':'') + '" onclick="toggleAuxMute()">M</button>' +
      '<button class="cb' + (auxSolo?' sl':'') + '" onclick="toggleAuxSolo()">S</button>' +
      '<span class="cn" style="color:#f0c040;font-weight:600">AUX</span>' +
      '<input type="range" class="cs" min="0" max="100" value="' + auxMasterVol + '" oninput="setAuxMasterVolFn(this.value);this.parentElement.querySelector(\'.cl\').textContent=this.value+\'%\'">' +
      '<span class="cl">' + auxMasterVol + '%</span>' +
      '<span class="co">' + auxChLabel + '</span>' +
      '</div>';
    auxTracks.forEach((t, i) => {
      const shortName = t.fn.length > 12 ? t.fn.substring(0,12)+'…' : t.fn;
      c.innerHTML +=
        '<div class="mix-ch" style="padding-left:1.5rem;opacity:.85">' +
        '<button class="cb' + (t.muted?' mt':'') + '" onclick="toggleAuxTrackMute(' + i + ')">M</button>' +
        '<span class="cn" style="color:#f0c040;font-size:.7rem" title="' + t.fn + '">' + shortName + '</span>' +
        '<input type="range" class="cs" min="0" max="100" value="' + t.vol + '" oninput="setAuxTrackVol(' + i + ',this.value);this.parentElement.querySelector(\'.cl\').textContent=this.value+\'%\'">' +
        '<span class="cl">' + t.vol + '%</span>' +
        '</div>';
    });
  }

  const monLoaded = MONITOR_SLOTS.filter(k => MON[k].buf);
  if (monLoaded.length > 0) {
    const monChLabel = rMode === 'multi' ? '8' : '—';
    c.innerHTML += '<div style="margin-top:.5rem;padding-top:.5rem;border-top:1px solid var(--border)"><div class="mix-title" style="color:#ff6464;margin-bottom:.3rem;font-size:.7rem">🎧 Q/Click Monitor</div></div>';
    MONITOR_SLOTS.forEach(k => {
      if (!MON[k].buf) return;
      const mcolor = MONITOR_COLORS[k];
      const mlabel = MONITOR_LABELS[k].split(' ')[1];
      c.innerHTML +=
        '<div class="mix-ch" style="border:1px solid rgba(255,100,100,.2);border-radius:8px">' +
        '<button class="cb' + (MON[k].muted?' mt':'') + '" onclick="toggleMonitorMute(\'' + k + '\')">M</button>' +
        '<span class="cn" style="color:' + mcolor + ';font-weight:600">' + mlabel + '</span>' +
        '<input type="range" class="cs" min="0" max="100" value="' + MON[k].vol + '" oninput="setMonitorVol(\'' + k + '\',this.value);this.parentElement.querySelector(\'.cl\').textContent=this.value+\'%\'">' +
        '<span class="cl">' + MON[k].vol + '%</span>' +
        '<span class="co" style="color:#ff6464">' + monChLabel + '</span>' +
        '</div>';
    });
  }
}

// ── Audio Output Routing ───────────────────────────────────────

function setRoute(m) {
  rMode = m;
  document.getElementById('rtStereo').classList.toggle('on', m === 'stereo');
  document.getElementById('rtMulti').classList.toggle('on', m === 'multi');
  rebuildRoute();
  renderRouting();
}

function rebuildRoute() {
  SK.forEach(k => { try { S[k].gn.disconnect(); } catch(e) {} });
  try { auxMasterGain.disconnect(); } catch(e) {}

  if (rMode === 'stereo') {
    SK.forEach(k => S[k].gn.connect(mGain));
    auxMasterGain.connect(mGain);
    return;
  }

  if (maxCh < 8) { alert('Need at least 8 output channels. Connect your audio interface and refresh.'); setRoute('stereo'); return; }
  try {
    AC.destination.channelCount = 8;
    AC.destination.channelCountMode = 'explicit';
    AC.destination.channelInterpretation = 'discrete';
  } catch(e) {}

  const merger = AC.createChannelMerger(8);
  merger.connect(AC.destination);

  const pianoSplit = AC.createChannelSplitter(2);
  S.piano.gn.connect(pianoSplit);
  pianoSplit.connect(merger, 0, 0);
  pianoSplit.connect(merger, 1, 1);

  const bassMono = AC.createGain(); S.bass.gn.connect(bassMono); bassMono.connect(merger, 0, 2);
  const guitarMono = AC.createGain(); S.guitar.gn.connect(guitarMono); guitarMono.connect(merger, 0, 3);
  const rhythmMono = AC.createGain(); S.rhythm.gn.connect(rhythmMono); rhythmMono.connect(merger, 0, 4);

  const auxSplit = AC.createChannelSplitter(2);
  auxMasterGain.connect(auxSplit);
  auxSplit.connect(merger, 0, 5);
  auxSplit.connect(merger, 1, 6);

  const monMono = AC.createGain();
  monitorMasterGain.connect(monMono);
  monMono.connect(merger, 0, 7);
}

function renderRouting() {
  const el = document.getElementById('rtPanel');
  if (rMode === 'stereo') {
    el.innerHTML = '<p style="font-size:.8rem;color:var(--text-dim)">All instruments and aux tracks to stereo output (Ch 1-2).</p>';
    return;
  }
  let h = '<p style="font-size:.8rem;color:var(--green);margin-bottom:.75rem">Fixed 8-channel routing active</p>';
  h += '<div class="rt-grid">';
  const routeInfo = [
    { name:'Piano',           color:SC.piano,    ch:'Ch 1-2', mode:'Stereo' },
    { name:'Bass',            color:SC.bass,     ch:'Ch 3',   mode:'Mono' },
    { name:'Guitar',          color:SC.guitar,   ch:'Ch 4',   mode:'Mono' },
    { name:'Rhythm',          color:'#ff4466',   ch:'Ch 5',   mode:'Mono' },
    { name:'Aux Stems',       color:'#f0c040',   ch:'Ch 6-7', mode:'Stereo' },
    { name:'Q/Click Monitor', color:'#ff6464',   ch:'Ch 8',   mode:'Mono — Monitor Only' }
  ];
  routeInfo.forEach(r => {
    h += '<div class="rt-row"><span class="rt-nm" style="color:' + r.color + '">' + r.name + '</span><span style="font-size:.75rem;color:var(--text-dim)">→</span><span style="font-size:.85rem;color:var(--text-secondary);padding:.35rem .5rem">' + r.ch + ' (' + r.mode + ')</span></div>';
  });
  el.innerHTML = h + '</div>';
}

// ── Mini Scrub Bar ─────────────────────────────────────────────

let scrubInterval = null;
const SCRUB_SPEED = 4;

function mtScrubStart(dir) {
  if (scrubInterval) return;
  scrubInterval = setInterval(() => {
    if (typeof vwbActiveEngine !== 'undefined' && vwbActiveEngine === 'midi') {
      const cur = (typeof getMidiCurrentTime === 'function') ? getMidiCurrentTime() : 0;
      const dur = (typeof midiDuration !== 'undefined' && typeof midiTempoPct !== 'undefined')
        ? midiDuration / (midiTempoPct / 100) : 0;
      if (dur <= 0) return;
      const newPos = Math.max(0, Math.min(dur, cur + dir * SCRUB_SPEED * 0.1));
      if (typeof seekMidi === 'function') seekMidi((newPos / dur) * 100);
    } else {
      const cur  = getCurTime(), dur = getDur();
      if (dur <= 0) return;
      jumpTo(Math.max(0, Math.min(dur, cur + dir * SCRUB_SPEED * 0.1)));
      updMtScrubBar();
    }
  }, 100);
}

function mtScrubStop() {
  if (scrubInterval) { clearInterval(scrubInterval); scrubInterval = null; }
}

function mtScrubClick(e) {
  const bar = document.getElementById('mtScrubBar');
  if (!bar) return;
  const r   = bar.getBoundingClientRect();
  const pct = (e.clientX - r.left) / r.width;
  if (typeof vwbActiveEngine !== 'undefined' && vwbActiveEngine === 'midi') {
    if (typeof seekMidi === 'function') seekMidi(pct * 100);
    updMtScrubBar();
    return;
  }
  const dur = getDur();
  if (dur > 0) { jumpTo(pct * dur); updMtScrubBar(); }
}

function updMtScrubBar() {
  const prog = document.getElementById('mtScrubProg');
  const secs = document.getElementById('mtScrubSecs');
  if (!prog) return;

  // Hide the scrub bar entirely when Organ engine is active — not applicable there
  const scrubWrap = document.getElementById('mtScrubBarWrap');
  if (scrubWrap) {
    const isOrgan = typeof vwbActiveEngine !== 'undefined' && vwbActiveEngine === 'organ';
    scrubWrap.style.display = isOrgan ? 'none' : '';
  }

  if (typeof vwbActiveEngine !== 'undefined' && vwbActiveEngine === 'midi') {
    const t   = (typeof getMidiCurrentTime === 'function') ? getMidiCurrentTime() : 0;
    const dur = (typeof midiDuration !== 'undefined' && typeof midiTempoPct !== 'undefined')
      ? midiDuration / (midiTempoPct / 100) : 0;
    if (dur > 0) prog.style.width = Math.min(100, (t / dur) * 100) + '%';
    // Draw song sections on scrub bar using MIDI bar math
    if (secs && song.secs.length > 0 && dur > 0) {
      if (secs.children.length !== song.secs.length) {
        secs.innerHTML = '';
        song.secs.forEach((s, i) => {
          const tUnscaled = t * ((typeof midiTempoPct !== 'undefined' ? midiTempoPct : 100) / 100);
          const st = (typeof midiBar2Time === 'function') ? midiBar2Time(s.sb) : 0;
          const et = (typeof midiBar2Time === 'function') ? midiBar2Time(s.eb + 1) : 0;
          const wp = ((et - st) / (dur * ((typeof midiTempoPct !== 'undefined' ? midiTempoPct : 100) / 100))) * 100;
          const label = (s.type === 'Custom' && s.customLabel) ? s.customLabel : s.type;
          secs.innerHTML += '<div class="mt-scrub-sec' + (i === curSec ? ' on' : '') + '" style="width:' + Math.min(wp, 100) + '%">' + label + '</div>';
        });
      } else {
        Array.from(secs.children).forEach((el, i) => el.classList.toggle('on', i === curSec));
      }
    }
    return;
  }

  const t = getCurTime(), dur = getDur();
  if (dur > 0) prog.style.width = ((t / dur) * 100) + '%';
  if (secs && secs.children.length !== song.secs.length) {
    secs.innerHTML = '';
    song.secs.forEach((s, i) => {
      const st = bar2time(s.sb), et = bar2time(s.eb + 1);
      const wp = ((et - st) / dur) * 100;
      const label = (s.type === 'Custom' && s.customLabel) ? s.customLabel : s.type;
      secs.innerHTML += '<div class="mt-scrub-sec' + (i===curSec?' on':'') + '" style="width:' + Math.min(wp,100) + '%">' + label + '</div>';
    });
  } else if (secs) {
    Array.from(secs.children).forEach((el, i) => el.classList.toggle('on', i === curSec));
  }
}

function initScrubButtons() {
  const rew = document.getElementById('mtRew');
  const fwd = document.getElementById('mtFwd');
  if (!rew || !fwd) return;
  rew.addEventListener('mousedown',  () => mtScrubStart(-1));
  rew.addEventListener('touchstart', (e) => { e.preventDefault(); mtScrubStart(-1); });
  fwd.addEventListener('mousedown',  () => mtScrubStart(1));
  fwd.addEventListener('touchstart', (e) => { e.preventDefault(); mtScrubStart(1); });
  ['mouseup','mouseleave'].forEach(ev => { rew.addEventListener(ev, mtScrubStop); fwd.addEventListener(ev, mtScrubStop); });
  ['touchend','touchcancel'].forEach(ev => { rew.addEventListener(ev, mtScrubStop); fwd.addEventListener(ev, mtScrubStop); });
}

// ── Panic ──────────────────────────────────────────────────────

function togglePanic() { panicActive ? panicRecover() : panicEngage(); }

function panicEngage() {
  if (!playing) return;
  panicActive = true;
  SK.forEach(k => { if (k === 'rhythm') return; if (S[k].gn) S[k].gn.gain.value = 0; });
  auxMasterGain.gain.value = 0;
  const btn = document.getElementById('panicBtn');
  if (btn) { btn.classList.add('active'); btn.textContent = '✓ RECOVER'; }
  showNotification('⚠ PANIC — Stems muted. Rhythm holding. Press RECOVER when ready.');
}

function panicRecover() {
  panicActive = false;
  const dur = 2, now = AC.currentTime;
  SK.forEach(k => {
    if (k === 'rhythm') return;
    if (S[k].gn && !S[k].muted) {
      const target = S[k].vol / 100;
      S[k].gn.gain.cancelScheduledValues(now);
      S[k].gn.gain.setValueAtTime(0, now);
      S[k].gn.gain.linearRampToValueAtTime(target, now + dur);
    }
  });
  const auxTarget = auxMasterMuted ? 0 : auxMasterVol / 100;
  auxMasterGain.gain.cancelScheduledValues(now);
  auxMasterGain.gain.setValueAtTime(0, now);
  auxMasterGain.gain.linearRampToValueAtTime(auxTarget, now + dur);
  const btn = document.getElementById('panicBtn');
  if (btn) { btn.classList.remove('active'); btn.textContent = '⚠ PANIC'; }
  showNotification('✓ Recovered — stems fading back in over 2 seconds');
}

// ── Keyboard Shortcuts ─────────────────────────────────────────

document.addEventListener('keydown', e => {
  if (['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName)) return;
  const onPerf  = document.getElementById('view-perform').classList.contains('active');
  const onSetup = document.getElementById('view-setup').classList.contains('active');
  if (!onPerf && !onSetup) return;

  // ── Armor Bearer keyboard triggers (Perform only) ──
  if (onPerf && typeof abHandleKey === 'function' && typeof abLoaded !== 'undefined' && abLoaded
      && typeof vwbActiveEngine !== 'undefined' && vwbActiveEngine === 'organ') {
    // Backtick ` — trigger current Armor Bearer level
    if (e.key === '`') {
      e.preventDefault();
      abHandleKey('`');
      return;
    }
    // Space bar triggers Armor Bearer when Organ engine is active
    if (e.key === ' ') {
      e.preventDefault();
      abTrigger(abCurrentKey, abCurrentLevel);
      return;
    }
    // Number keys 1-4 — select Armor Bearer level
    if (['1','2','3','4'].includes(e.key)) {
      e.preventDefault();
      abHandleKey(e.key);
      return;
    }
  }

  // ── Rubato Mode space bar — trigger next phrase (Setup page, MIDI engine) ──
  if (e.key === ' ' && onSetup) {
    const rubatoBody = document.getElementById('rubatoCardBody');
    const rubatoOpen = rubatoBody && rubatoBody.style.display !== 'none';
    if (rubatoOpen && typeof rbManualNext === 'function' && typeof rbPhrases !== 'undefined' && rbPhrases.length) {
      e.preventDefault();
      rbManualNext();
      return;
    }
  }

  if (e.key === ' ') {
    e.preventDefault();
    if (onPerf && typeof uniTogglePlay === 'function') {
      uniTogglePlay();
    } else {
      togglePlay();
    }
    return;
  }
  if (e.key === 'Escape') {
    e.preventDefault();
    if (typeof uniStop === 'function') uniStop(); else doStop();
    return;
  }
  if (e.key === 'l' || e.key === 'L') { e.preventDefault(); toggleLoop();   return; }
  if (e.key === 'r' || e.key === 'R') {
    e.preventDefault();
    if (typeof uniToggleSecLoop === 'function') uniToggleSecLoop(); else toggleSecLoop();
    return;
  }
  if (e.key === 'p' || e.key === 'P') { e.preventDefault(); togglePanic(); return; }

  if (onPerf) {
    if (e.key >= '5' && e.key <= '9') {
      const i = parseInt(e.key) - 1;
      if (typeof uniJumpSection === 'function') {
        uniJumpSection(i);
      } else {
        if (typeof midiSections !== 'undefined' && midiSections.length > i) jumpMidiSection(i);
        if (i < song.secs.length) queueSection(i);
      }
    }
    if (e.key === 'n' || e.key === 'N') {
      const maxSec = isMidiPrimary && isMidiPrimary() ? midiSections.length : song.secs.length;
      const curIdx = isMidiPrimary && isMidiPrimary() ? midiCurSec : curSec;
      if (curIdx < maxSec - 1) uniJumpSection(curIdx + 1);
    }
    if (e.key === 'b' || e.key === 'B') {
      const curIdx = isMidiPrimary && isMidiPrimary() ? midiCurSec : curSec;
      if (curIdx > 0) uniJumpSection(curIdx - 1);
    }
  }
});

// ═══════════════════════════════════════════════════════════════
//  VWB Sunday Edition — Drag & Drop
//  Drop audio/MIDI files onto stems, aux, loops, MIDI, monitor.
// ═══════════════════════════════════════════════════════════════

function initDragAndDrop() {

  // ── Helper: extract file path from drag event ────────────────
  function getDroppedFiles(e) {
    const files = [];
    if (e.dataTransfer.files && e.dataTransfer.files.length) {
      for (const f of e.dataTransfer.files) {
        if (f.path) files.push({ path: f.path, name: f.name });
      }
    }
    return files;
  }

  function prevent(e) { e.preventDefault(); e.stopPropagation(); }

  // ── Stem Slots — individual slots get drag events ────────────
  function addStemSlotDrop(el, k) {
    el.addEventListener('dragover',  e => { prevent(e); el.classList.add('drag-over'); });
    el.addEventListener('dragleave', e => { prevent(e); el.classList.remove('drag-over'); });
    el.addEventListener('drop', async e => {
      prevent(e);
      el.classList.remove('drag-over');
      const files = getDroppedFiles(e);
      if (!files.length) return;
      const file = files[0];
      const songTitle = document.getElementById('songTitle').value || 'untitled';
      const stored = await window.vwb.storeStem({ songTitle, stemKey: k, sourcePath: file.path, fileName: file.name });
      if (stored.success) await loadStemFromPath(k, stored.storedPath, file.name);
    });
  }

  // Attach to stem slots after they render
  const stemObserver = new MutationObserver(() => {
    SK.forEach(k => {
      const slots = document.querySelectorAll(`#stemsGrid .stem-slot`);
      slots.forEach((slot, i) => {
        const stemKey = SK[i];
        if (stemKey && !slot.dataset.dropReady) {
          slot.dataset.dropReady = '1';
          addStemSlotDrop(slot, stemKey);
        }
      });
    });
  });
  const stemsGrid = document.getElementById('stemsGrid');
  if (stemsGrid) stemObserver.observe(stemsGrid, { childList: true });

  // ── Aux Tracks ───────────────────────────────────────────────
  const auxList = document.getElementById('auxTracksList');
  if (auxList) {
    auxList.addEventListener('dragover',  e => { prevent(e); auxList.classList.add('drag-over'); });
    auxList.addEventListener('dragleave', e => { prevent(e); auxList.classList.remove('drag-over'); });
    auxList.addEventListener('drop', async e => {
      prevent(e);
      auxList.classList.remove('drag-over');
      const files = getDroppedFiles(e);
      if (!files.length) return;
      const songTitle = document.getElementById('songTitle').value || 'untitled';
      for (const file of files) {
        const stored = await window.vwb.storeStem({
          songTitle,
          stemKey: 'aux_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
          sourcePath: file.path, fileName: file.name
        });
        if (stored.success) await addAuxTrackFromPath(stored.storedPath, file.name);
      }
    });
  }

  // ── Monitor Bus ──────────────────────────────────────────────
  const monList = document.getElementById('monitorBusList');
  if (monList) {
    monList.addEventListener('dragover',  e => { prevent(e); monList.classList.add('drag-over'); });
    monList.addEventListener('dragleave', e => { prevent(e); monList.classList.remove('drag-over'); });
    monList.addEventListener('drop', async e => {
      prevent(e);
      monList.classList.remove('drag-over');
      const files = getDroppedFiles(e);
      if (!files.length) return;
      const songTitle = document.getElementById('songTitle').value || 'untitled';
      // Fill empty slots first — don't overwrite what's already loaded
      const emptySlots = ['cues', 'click'].filter(s => !MON[s].buf);
      if (!emptySlots.length) {
        showNotification('⚠ Both Cues and Click are filled. Remove one first.');
        return;
      }
      for (let i = 0; i < Math.min(files.length, emptySlots.length); i++) {
        const file = files[i];
        const slot = emptySlots[i];
        const stored = await window.vwb.storeStem({
          songTitle, stemKey: 'mon_' + slot,
          sourcePath: file.path, fileName: file.name
        });
        const path = stored.success ? stored.storedPath : file.path;
        await loadMonitorFromPath(slot, path, file.name);
      }
    });
  }

  // ── Loop Library ─────────────────────────────────────────────
  const loopLib = document.getElementById('loopLibrary');
  if (loopLib) {
    loopLib.addEventListener('dragover',  e => { prevent(e); loopLib.classList.add('drag-over'); });
    loopLib.addEventListener('dragleave', e => { prevent(e); loopLib.classList.remove('drag-over'); });
    loopLib.addEventListener('drop', async e => {
      prevent(e);
      loopLib.classList.remove('drag-over');
      const files = getDroppedFiles(e);
      if (!files.length) return;
      const songTitle = document.getElementById('songTitle').value || 'untitled';
      for (const file of files) {
        const stored = await window.vwb.storeStem({
          songTitle,
          stemKey: 'bgloop_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
          sourcePath: file.path, fileName: file.name
        });
        if (stored.success) await addLoopFromPath(stored.storedPath, file.name);
        else await addLoopFromPath(file.path, file.name);
      }
    });
  }

  // ── MIDI Panel ───────────────────────────────────────────────
  const midiBody = document.getElementById('midiPanelBody');
  if (midiBody) {
    midiBody.addEventListener('dragover',  e => { prevent(e); midiBody.classList.add('drag-over'); });
    midiBody.addEventListener('dragleave', e => { prevent(e); midiBody.classList.remove('drag-over'); });
    midiBody.addEventListener('drop', async e => {
      prevent(e);
      midiBody.classList.remove('drag-over');
      const files = getDroppedFiles(e);
      if (!files.length) return;
      if (midiPlaylist.length >= 8) { alert('Maximum 8 MIDI files reached.'); return; }
      const songTitle = document.getElementById('songTitle').value || 'untitled';
      for (const file of files) {
        if (!file.name.toLowerCase().endsWith('.mid') && !file.name.toLowerCase().endsWith('.midi')) {
          showNotification('⚠ ' + file.name + ' is not a MIDI file');
          continue;
        }
        const stored = await window.vwb.storeStem({
          songTitle, stemKey: 'midi_' + Date.now(),
          sourcePath: file.path, fileName: file.name
        });
        const storedPath = stored.success ? stored.storedPath : file.path;
        const rb = await window.vwb.readFileBuffer(file.path);
        if (rb.success) await addMidiFileFromBuffer(rb.buffer, file.name, storedPath);
      }
    });
  }
}

// Init drag and drop after app loads
document.addEventListener('DOMContentLoaded', () => {
  // Small delay to ensure all DOM elements are rendered
  setTimeout(initDragAndDrop, 500);
});
