// ═══════════════════════════════════════════════════════════════
//  VWB — Rubato Mode
//  Voice-triggered MIDI phrase playback for live worship.
//  Listens to singer via Web Speech API, matches trigger words
//  to MIDI chunks, plays them in C (transposable to any key).
// ═══════════════════════════════════════════════════════════════

// ── State ──────────────────────────────────────────────────────
let rbPhrases        = [];     // [{words, trigger, midiFile, midiData}, ...]
let rbCurrentIdx     = -1;     // index of currently playing phrase
let rbLyricsText     = '';     // raw lyrics text content
let rbChunkFolder    = '';     // path to MIDI chunk folder
let rbChunkFiles     = {};     // { triggerWord: filePath }
let rbTranspose      = 0;      // semitones from C (-11 to +11)
let rbOctave         = 0;      // octave shift (-2 to +2)
let rbConfidence     = 0.35;   // speech recognition confidence threshold
let rbListening      = false;  // is speech recognition active?
let rbKeyDetecting   = false;  // is key detection active? (separate from word listening)
let rbPlaying        = false;  // is a chunk currently playing?
let rbRecognizer     = null;   // SpeechRecognition instance
let rbMidiOut        = null;   // WebMIDI output (reuses main midi port)
let rbActiveNotes    = [];     // notes currently sounding (for instant cut)
let rbFxOpen         = false;  // FX panel open state
let rbSongMapOpen    = false;  // Song Map open state
let rbReverbType     = 'none';
let rbReverbAmount   = 30;
let rbReverbSend     = null;
let rbHallConv       = null;
let rbPlateConv      = null;
let rbReverbOut      = null;
let rbGain           = null;

// ── VWB Pack state (loaded from .vwb file) ─────────────────────
let rbVwbPack        = null;   // full parsed .vwb JSON
let rbSongTitle      = '';     // song title from pack
let rbArtistName     = '';     // pianist name from pack
let rbArtistRole     = '';     // role from pack
let rbArtistPhoto    = null;   // base64 photo from pack
let rbPackLoaded     = false;  // true when a .vwb pack is loaded

// Key names for transposition display
const RB_KEY_NAMES = ['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B'];

// ── VWB Pack Loader ────────────────────────────────────────────
// Loads a .vwb file produced by VWB Studio and populates Rubato
// Mode with song title, artist info, phrases, and MIDI data.

async function rbLoadVwbPack() {
  try {
    // Use same pickAnyFile pattern as rbLoadLyricsFile
    const result = await window.vwb.pickAnyFile({ title: 'Load VWB Song Pack' });
    if (!result || result.canceled || !result.filePaths || !result.filePaths.length) return;

    const filePath = result.filePaths[0];
    console.log('[Rubato] Loading .vwb pack from:', filePath);

    // Use same readFileBuffer pattern as rbLoadLyricsFile
    const rb = await window.vwb.readFileBuffer(filePath);
    if (!rb || !rb.success) {
      showNotification('❌ Could not read song pack file');
      return;
    }

    const text = new TextDecoder('utf-8').decode(new Uint8Array(rb.buffer));
    let pack;
    try {
      pack = JSON.parse(text);
    } catch(parseErr) {
      showNotification('❌ Song pack file is not valid JSON');
      console.error('[Rubato] JSON parse error:', parseErr);
      return;
    }

    if (pack.format !== 'vwb-rubato-pack') {
      showNotification('⚠ Not a valid VWB song pack file');
      return;
    }

    // Store pack data
    rbVwbPack     = pack;
    rbPackLoaded  = true;
    rbSongTitle   = pack.song?.title   || '';
    rbArtistName  = pack.artist?.name  || '';
    rbArtistRole  = pack.artist?.role  || 'Pianist';
    rbArtistPhoto = pack.artist?.photo || null;

    // Set key from pack — user can override manually anytime
    const packKey = pack.song?.key || 'C';
    const keyIdx  = RB_KEY_NAMES.indexOf(packKey);
    if (keyIdx >= 0) rbTranspose = keyIdx;

    // Build phrases from .vwb phrase map
    rbPhrases    = [];
    rbChunkFiles = {};

    if (pack.phrases && pack.phrases.length) {
      pack.phrases.forEach((p) => {
        // Skip section label entries and entries with no valid timing
        if (!p.trigger) return;
        if (p.trigger === 'verse' || p.trigger === 'chorus') return;
        if (p.startTime === null || p.startTime === undefined) return;
        if (p.duration !== null && p.duration <= 0) return;

        rbPhrases.push({
          line:      p.line      || p.trigger,
          trigger:   p.trigger,
          firstWord: p.trigger,
          section:   p.section   || '',
          startTime: p.startTime,
          endTime:   p.endTime,
          duration:  p.duration,
          midiData:  null
        });

        // Register trigger word so rbPlayChunk can find it
        rbChunkFiles[p.trigger] = '__vwb_pack__'; // flag — no file path needed
      });
    }

    // Build melodic fingerprint from pack for key detection
    if (pack.melodicStructure && pack.melodicStructure.length) {
      _rbBuildFingerprintFromPack(pack);
    }

    // Reset position
    rbCurrentIdx = -1;
    rbPitchLocked = false;

    renderRubatoCard();
    showNotification('✅ ' + rbSongTitle + ' — ' + rbPhrases.length + ' phrases loaded');
    console.log('[Rubato] VWB Pack loaded:', rbSongTitle, '—', rbPhrases.length, 'phrases');

  } catch(e) {
    console.error('[Rubato] Error loading .vwb pack:', e);
    showNotification('❌ Could not load song pack: ' + e.message);
  }
}

// Build song fingerprint from .vwb melodic structure for key detection
function _rbBuildFingerprintFromPack(pack) {
  const structure = pack.melodicStructure || [];
  const degrees   = structure
    .filter(s => s.degree !== null && s.degree !== '')
    .map(s => {
      const d = String(s.degree).trim();
      // Parse degree — handle b3, #4, 3, etc
      if (d.startsWith('b')) return parseFloat(d.slice(1)) - 0.5;
      if (d.startsWith('#')) return parseFloat(d.slice(1)) + 0.5;
      return parseFloat(d);
    })
    .filter(d => !isNaN(d) && d >= 1 && d <= 8);

  if (degrees.length < 5) return; // not enough data

  // Build interval sequence
  const intervals = [];
  for (let i = 1; i < degrees.length; i++) {
    intervals.push(Math.round((degrees[i] - degrees[i-1]) * 2) / 2);
  }

  // Add to fingerprint database
  RB_SONG_FINGERPRINTS.unshift({
    name:      pack.song?.title || 'Unknown',
    degrees,
    intervals
  });

  console.log('[Rubato] Built fingerprint from pack:', degrees.length, 'degrees,', intervals.length, 'intervals');
}

// ── Audio Init ─────────────────────────────────────────────────
function rbInitAudio() {
  if (rbGain) return;
  rbGain = AC.createGain();
  rbGain.gain.value = 1.0;
  rbGain.connect(mGain);

  rbReverbOut = AC.createGain();
  rbReverbOut.gain.value = 0.75;
  rbReverbOut.connect(mGain);

  rbReverbSend = AC.createGain();
  rbReverbSend.gain.value = rbReverbAmount / 100;
  rbGain.connect(rbReverbSend);

  rbHallConv = AC.createConvolver();
  rbHallConv.buffer = _rbMakeImpulse(3.5, 2.0);

  rbPlateConv = AC.createConvolver();
  rbPlateConv.buffer = _rbMakeImpulse(1.6, 3.5);

  _rbConnectReverb();

  // Preload the acoustic piano sampler so first trigger fires instantly
  setTimeout(() => rbPreloadPiano(), 500);
}

function _rbMakeImpulse(dur, decay) {
  const len = Math.floor(AC.sampleRate * dur);
  const buf = AC.createBuffer(2, len, AC.sampleRate);
  for (let c = 0; c < 2; c++) {
    const d = buf.getChannelData(c);
    for (let i = 0; i < len; i++) {
      d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
    }
  }
  return buf;
}

function _rbConnectReverb() {
  if (!rbReverbSend) return;
  try { rbReverbSend.disconnect(); } catch(e) {}
  if (rbReverbType === 'hall'  && rbHallConv)  { rbReverbSend.connect(rbHallConv);  rbHallConv.connect(rbReverbOut);  }
  if (rbReverbType === 'plate' && rbPlateConv) { rbReverbSend.connect(rbPlateConv); rbPlateConv.connect(rbReverbOut); }
}

function rbSetReverbType(type) {
  rbReverbType = type;
  _rbConnectReverb(); // native chain
  // Also update Tone reverb — reconnect sampler to correct bus
  if (typeof _loadChannelSampler === 'function') {
    const sampler = _chSampler ? _chSampler[RB_MIDI_CH] : null;
    if (sampler) {
      // Disconnect from both reverb buses first
      try { if (_rbToneHall)  sampler.disconnect(_rbToneHall);  } catch(e) {}
      try { if (_rbTonePlate) sampler.disconnect(_rbTonePlate); } catch(e) {}
      // Reconnect to the selected one
      _rbRouteSamplerThroughReverb(sampler);
    }
  }
  renderRubatoCard();
}

function rbSetReverbAmount(pct) {
  rbReverbAmount = parseInt(pct);
  if (rbReverbSend) rbReverbSend.gain.value = rbReverbAmount / 100;
  // Update Tone reverb wet level
  const wetVal = rbReverbAmount / 100;
  if (_rbToneHall  && rbReverbType === 'hall')  _rbToneHall.wet.value  = wetVal;
  if (_rbTonePlate && rbReverbType === 'plate') _rbTonePlate.wet.value = wetVal;
  const el = document.getElementById('rbRevAmtVal');
  if (el) el.textContent = pct + '%';
}

// ── Lyrics Parser ──────────────────────────────────────────────
// Lyrics are comma-separated phrases.
// Each phrase's FIRST word is the trigger word.
// Example: "Great is thy faithfulness, Oh God my, Father, There is no shadow"
// Trigger words: great, oh, father, there
//
// Also supports line-break format (.txt) and RTF files.

function _rbStripRtf(raw) {
  // Strip RTF header and control words, convert \par to comma delimiter
  return raw
    .replace(/\{\\rtf[\s\S]*?(?=\\pard|\\par\b|[A-Za-z])/g, '') // strip header
    .replace(/\\par[d]?\b\*?/g, ',')    // \par → comma (phrase break)
    .replace(/\\\w+\*?\s?/g, '')        // strip all other control words
    .replace(/[{}]/g, '')               // strip braces
    .replace(/\\/g, '')                 // strip remaining backslashes
    .replace(/,+/g, ',')               // collapse multiple commas
    .replace(/^\s*,|,\s*$/g, '')        // trim leading/trailing commas
    .trim();
}

function _rbExtractTriggerFromFilename(filename) {
  let name = filename.split('/').pop().split('\\').pop();
  name = name.replace(/\.midi?$/i, '');

  // Try curly/smart quotes first: \u201cFather\u201d (Mac default)
  const curlyMatch = name.match(/\u201c(.+?)\u201d/);
  if (curlyMatch) {
    name = curlyMatch[1];
  } else {
    // Try straight quotes: "Father"
    const straightMatch = name.match(/"(.+?)"/);
    if (straightMatch) {
      name = straightMatch[1];
    } else {
      // Try 22...22 URL-encoded quotes (older naming)
      const encoded = name.match(/22(.+?)22/i);
      if (encoded) {
        name = encoded[1];
      } else {
        // Try [brackets]: [Intro]
        const brackets = name.match(/\[(.+?)\]/);
        if (brackets) {
          name = brackets[1];
        } else {
          // Strip common prefixes like GITF__ or GITF_
          name = name.replace(/^[A-Z]+__?/i, '');
        }
      }
    }
  }

  // Get first meaningful word
  const words = name.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').trim().split(/\s+/);
  // Special: "oh" at start matches "o" in lyrics (TextEdit drops the h in "O God")
  if (words[0] === 'oh') return 'o';
  // Return first word — even short ones like 'o'
  return words[0] || '';
}

function _rbStripRtf(raw) {
  // TextEdit Mac RTF: text starts after \cf0
  // Phrase breaks = backslash + newline (\<LF>)
  let text = raw;
  const cfMatch = text.match(/\\cf0\s*([\s\S]*)/);
  if (cfMatch) text = cfMatch[1];
  text = text.replace(/\\\n/g, ',');            // backslash+newline → comma
  text = text.replace(/\\uc0\\u8232\s*/g, ','); // Unicode line sep → comma
  text = text.replace(/\\par[d]?\b\*?\s*/g, ','); // \par → comma
  text = text.replace(/\\[a-zA-Z]+\*?-?\d*\s?/g, ''); // strip RTF controls
  text = text.replace(/[{}]/g, '');             // strip braces
  text = text.replace(/\\/g, '');               // strip stray backslashes
  text = text.replace(/,+/g, ',').replace(/^,|,$/g, '').trim();
  return text;
}

function rbParseLyrics() {
  if (!rbLyricsText) return;

  let text = rbLyricsText;

  // Strip RTF if needed
  if (text.trim().startsWith('{\\rtf') || text.includes('\\cf0') || text.includes('\\par')) {
    text = _rbStripRtf(text);
  }

  // Fallback: plain newlines → commas
  if (!text.includes(',') && text.includes('\n')) {
    text = text.split('\n').map(l => l.trim()).filter(l => l).join(',');
  }

  // Split on commas — each segment is one phrase
  const phrases = text.split(',').map(p => p.trim()).filter(p => p.length > 0);

  rbPhrases = phrases.map((phrase, i) => {
    const words = phrase.toLowerCase().split(/\s+/);
    // Strip brackets from first word: [Intro] → intro
    const firstWord = words[0].replace(/[^a-z0-9]/g, '');

    // Find matching chunk
    let trigger = null;
    if (rbChunkFiles[firstWord]) {
      trigger = firstWord;
    } else {
      for (const [chunkKey, filePath] of Object.entries(rbChunkFiles)) {
        const extracted = _rbExtractTriggerFromFilename(filePath || chunkKey);
        if (extracted === firstWord) { trigger = chunkKey; break; }
      }
    }

    const displayLine = phrase.replace(/^\[(.+)\]$/, '$1').trim();
    return { line: displayLine, words, trigger, firstWord, idx: i };
  });

  rbCurrentIdx = -1;

  console.log('[Rubato] Parsed ' + rbPhrases.length + ' phrases. Chunks loaded:', Object.keys(rbChunkFiles));
  rbPhrases.forEach((p, i) => {
    console.log('  ' + (i+1) + '. "' + p.line + '" → trigger: ' + (p.trigger || '(none — firstWord: ' + p.firstWord + ')'));
  });

  renderRubatoCard();
}

// ── Chunk Folder Loading ───────────────────────────────────────
async function rbSelectChunkFolder() {
  const result = await window.vwb.pickAnyFile({ title: 'Select MIDI Chunk Files', multi: true });
  if (!result || result.canceled || !result.filePaths.length) return;

  rbChunkFiles = {};

  result.filePaths.forEach(filePath => {
    const name = filePath.split('/').pop().split('\\').pop().toLowerCase();
    if (name.endsWith('.mid') || name.endsWith('.midi')) {
      const trigger = _rbExtractTriggerFromFilename(name);
      if (trigger) rbChunkFiles[trigger] = filePath;
    }
  });

  rbChunkFolder = Object.keys(rbChunkFiles).length + ' chunks loaded';
  rbParseLyrics();
  renderRubatoCard();
  showNotification('🎹 Rubato: ' + Object.keys(rbChunkFiles).length + ' chunks loaded');
}

async function rbLoadLyricsFile() {
  const result = await window.vwb.pickAnyFile({ title: 'Select Lyrics File (.txt or .rtf)' });
  if (!result || result.canceled || !result.filePaths.length) return;
  const filePath = result.filePaths[0];
  try {
    const rb = await window.vwb.readFileBuffer(filePath);
    if (!rb || !rb.success) { showNotification('❌ Could not read lyrics file'); return; }
    const decoder = new TextDecoder('utf-8');
    rbLyricsText = decoder.decode(new Uint8Array(rb.buffer));
    rbParseLyrics();
    showNotification('📄 Lyrics loaded — ' + rbPhrases.length + ' phrases');
  } catch(e) {
    showNotification('❌ Could not read lyrics file: ' + e.message);
  }
}

// ── Transposition ──────────────────────────────────────────────
function rbSetTranspose(delta) {
  rbTranspose = Math.max(-11, Math.min(11, rbTranspose + delta));
  renderRubatoCard();
}

function rbSetOctave(delta) {
  rbOctave = Math.max(-2, Math.min(2, rbOctave + delta));
  renderRubatoCard();
}

function rbGetKeyName() {
  const idx = ((rbTranspose % 12) + 12) % 12;
  return RB_KEY_NAMES[idx];
}

// ── MIDI Chunk Playback ────────────────────────────────────────
// Reads a MIDI file, transposes all note events, plays via internal synth.
async function rbPlayChunk(phraseIdx) {
  if (phraseIdx < 0 || phraseIdx >= rbPhrases.length) return;
  const phrase = rbPhrases[phraseIdx];
  if (!phrase.trigger || !rbChunkFiles[phrase.trigger]) return;

  // Stop current playback instantly
  rbStopCurrent();

  rbCurrentIdx = phraseIdx;
  rbPlaying    = true;
  renderRubatoCard();

  try {
    const filePath = rbChunkFiles[phrase.trigger];
    const rb = await window.vwb.readFileBuffer(filePath);
    if (!rb || !rb.success) { rbPlaying = false; renderRubatoCard(); return; }

    // Parse and play MIDI with transpose + octave
    const semitones = rbTranspose + (rbOctave * 12);
    await _rbPlayMidiBuffer(rb.buffer, semitones);
  } catch(e) {
    console.error('[Rubato] Playback error:', e);
    rbPlaying = false;
    renderRubatoCard();
  }
}

function rbStopCurrent() {
  rbPlaying = false;
  // Clear all pending note timers immediately
  rbActiveNotes.forEach(t => clearTimeout(t));
  rbActiveNotes = [];
  // Send all notes off on the Rubato piano channel specifically
  if (typeof synthAllNotesOff === 'function') synthAllNotesOff();
  // Force note off for all 128 notes on the Rubato channel
  // This ensures no notes linger even if synth channel differs
  if (typeof synthNoteOff === 'function') {
    for (let n = 0; n < 128; n++) {
      try { synthNoteOff(RB_MIDI_CH, n); } catch(e) {}
    }
  }
}

// Dedicated Rubato channel — always uses Acoustic Grand Piano (program 0)
const RB_MIDI_CH = 15;  // channel 15 reserved for rubato so it doesn't conflict with song MIDI

// Preload the piano sampler — force built-in sounds ON, route through reverb chain
async function rbPreloadPiano() {
  if (typeof setSynthMode === 'function') setSynthMode(true);
  if (typeof _loadChannelSampler === 'function') {
    const sampler = await _loadChannelSampler(RB_MIDI_CH, 0);
    console.log('[Rubato] Piano sampler ready on ch' + (RB_MIDI_CH + 1));
    _rbRouteSamplerThroughReverb(sampler);
  } else {
    console.warn('[Rubato] _loadChannelSampler not found');
  }
}

// ── Rubato Reverb via Tone.js ──────────────────────────────────
// We use Tone.js Reverb connected after the sampler — this stays
// inside Tone's graph and avoids native node connection issues.
let _rbToneHall  = null;
let _rbTonePlate = null;
let _rbToneSend  = null;   // Tone.Volume — reverb send level

function _rbEnsureToneReverb() {
  if (_rbToneHall) return;
  _rbToneHall = new Tone.Reverb({ decay: 3.5, preDelay: 0.04, wet: 1.0 }).toDestination();
  _rbToneHall.generate();
  _rbTonePlate = new Tone.Reverb({ decay: 1.6, preDelay: 0.01, wet: 1.0 }).toDestination();
  _rbTonePlate.generate();
  _rbToneSend = new Tone.Volume(-80).toDestination(); // start silent
  console.log('[Rubato] Tone reverb buses ready');
}

// Route the Tone.js sampler's output through reverb
function _rbRouteSamplerThroughReverb(sampler) {
  if (!sampler) return;
  try {
    _rbEnsureToneReverb();
    // Connect sampler → active reverb bus (in addition to default dry output)
    if (rbReverbType === 'hall'  && _rbToneHall)  {
      sampler.connect(_rbToneHall);
      _rbToneHall.wet.value = rbReverbAmount / 100;
    } else if (rbReverbType === 'plate' && _rbTonePlate) {
      sampler.connect(_rbTonePlate);
      _rbTonePlate.wet.value = rbReverbAmount / 100;
    }
    console.log('[Rubato] Reverb connected — type:', rbReverbType, 'amount:', rbReverbAmount);
  } catch(e) {
    console.warn('[Rubato] Reverb routing error:', e.message);
  }
}

// Parse minimal MIDI and schedule notes through the internal synth
async function _rbPlayMidiBuffer(buffer, semitones) {
  const bytes  = new Uint8Array(buffer);
  const parsed = _rbParseMidi(bytes);
  if (!parsed.events.length) { rbPlaying = false; renderRubatoCard(); return; }

  const events  = parsed.events;
  const tempo   = parsed.tempo || 500000;  // microseconds per beat (default 120 BPM)
  const ppq     = parsed.ppq   || 480;
  const msPerTick = (tempo / ppq) / 1000;  // ms per tick using real tempo

  // Ensure synth is ON and piano is loaded before scheduling notes
  if (typeof setSynthMode === 'function') setSynthMode(true);
  if (typeof _loadChannelSampler === 'function') {
    const sampler = await _loadChannelSampler(RB_MIDI_CH, 0);
    _rbRouteSamplerThroughReverb(sampler);
  }
  console.log('[Rubato] Playing ' + events.length + ' note events, tempo=' + tempo + 'µs, ppq=' + ppq + ', msPerTick=' + msPerTick.toFixed(3));

  // Sustain pedal state — tracks which notes are held by pedal
  let sustainDown   = false;
  const heldByPedal = new Set();  // notes held open because pedal is down

  events.forEach(ev => {
    const delayMs = ev.tick * msPerTick;
    const t = setTimeout(() => {
      if (!rbPlaying) return;
      const note = Math.max(0, Math.min(127, (ev.note || 0) + semitones));

      if (ev.type === 'on' && ev.vel > 0) {
        synthNoteOn(RB_MIDI_CH, note, ev.vel, 0);
        heldByPedal.delete(note); // re-striking clears pedal hold

      } else if (ev.type === 'off' || (ev.type === 'on' && ev.vel === 0)) {
        if (sustainDown) {
          // Pedal is down — don't release yet, just mark as held
          heldByPedal.add(note);
        } else {
          synthNoteOff(RB_MIDI_CH, note);
        }

      } else if (ev.type === 'sustain') {
        if (ev.value >= 64) {
          // Pedal pressed
          sustainDown = true;
        } else {
          // Pedal released — now release all notes that were held by pedal
          sustainDown = false;
          heldByPedal.forEach(n => synthNoteOff(RB_MIDI_CH, n));
          heldByPedal.clear();
        }
      }
    }, delayMs);
    rbActiveNotes.push(t);
  });

  // After last note — mark not playing
  const lastTick  = Math.max(...events.map(e => e.tick));
  const endDelay  = (lastTick * msPerTick) + 800;  // 800ms tail for note release
  const endTimer  = setTimeout(() => {
    rbPlaying     = false;
    rbActiveNotes = [];
    renderRubatoCard();
  }, endDelay);
  rbActiveNotes.push(endTimer);
}

// Minimal MIDI parser — extracts note on/off events with absolute ticks
// Returns { events, tempo (µs/beat), ppq }
function _rbParseMidi(bytes) {
  const events = [];
  let pos = 0;
  let tempo = 500000;  // default 120 BPM

  function readUint32() { return (bytes[pos++]<<24)|(bytes[pos++]<<16)|(bytes[pos++]<<8)|bytes[pos++]; }
  function readUint16() { return (bytes[pos++]<<8)|bytes[pos++]; }
  function readVarLen() {
    let val = 0, b;
    do { b = bytes[pos++]; val = (val << 7) | (b & 0x7F); } while (b & 0x80);
    return val;
  }

  if (readUint32() !== 0x4D546864) return { events, tempo, ppq: 480 };
  pos += 4; // header length
  pos += 2; // format
  const numTracks = readUint16();
  const ppq = readUint16();

  for (let t = 0; t < numTracks; t++) {
    if (pos + 8 > bytes.length) break;
    if (readUint32() !== 0x4D54726B) break;
    const trackLen = readUint32();
    const trackEnd = pos + trackLen;
    let tick = 0;
    let lastStatus = 0;

    while (pos < trackEnd) {
      tick += readVarLen();
      let status = bytes[pos];

      if (status & 0x80) { lastStatus = status; pos++; }
      else { status = lastStatus; }

      const type = (status >> 4) & 0xF;
      const ch   = status & 0xF;

      if (type === 0x9 || type === 0x8) {
        const note = bytes[pos++];
        const vel  = bytes[pos++];
        events.push({ tick, type: type === 0x9 ? 'on' : 'off', ch, note, vel });
      } else if (type === 0xA) { pos += 2; }
      else if (type === 0xB) {
        // Control Change — capture CC64 (sustain pedal)
        const cc  = bytes[pos++];
        const val = bytes[pos++];
        if (cc === 64) {
          events.push({ tick, type: 'sustain', ch, value: val });
        }
      }
      else if (type === 0xC) { pos += 1; }
      else if (type === 0xD) { pos += 1; }
      else if (type === 0xE) { pos += 2; }
      else if (type === 0xF) {
        if (status === 0xFF) {
          const metaType = bytes[pos++];
          const metaLen  = readVarLen();
          if (metaType === 0x51 && metaLen === 3) {
            // Tempo meta event — extract µs per beat
            tempo = (bytes[pos] << 16) | (bytes[pos+1] << 8) | bytes[pos+2];
          }
          pos += metaLen;
        } else if (status === 0xF0 || status === 0xF7) {
          const len = readVarLen(); pos += len;
        } else { pos++; }
      } else { pos++; }
    }
    pos = trackEnd;
  }

  events.sort((a, b) => a.tick - b.tick);
  return { events, tempo, ppq };
}

// ── Pitch Detection & Melodic Key Detection Engine ────────────
// Runs alongside Vosk on the same mic stream. Detects pitches
// being sung, builds interval pattern, matches against song
// melodic fingerprints, and auto-sets the key in Rubato Mode.
//
// Melodic fingerprint format: array of scale degrees (1-7)
// representing the melody syllable by syllable.
// Intervals are calculated between consecutive degrees.

const RB_SONG_FINGERPRINTS = [
  {
    name: 'Great Is Thy Faithfulness',
    // Scale degrees: Great=3 Is=3 Thy=3 Faith=3 Ful=2 Ness=2 Oh=4 God=4 My=5 Fa=4 Ther=3
    degrees: [3, 3, 3, 3, 2, 2, 4, 4, 5, 4, 3],
    // Intervals between consecutive degrees (degree[i+1] - degree[i])
    intervals: [0, 0, 0, -1, 0, 2, 0, 1, -1, -1]
  }
  // More songs can be added here in future sessions
];

// Pitch detection state
let rbPitchCtx        = null;   // AudioContext for pitch detection
let rbPitchSource     = null;   // MediaStreamAudioSourceNode
let rbPitchAnalyser   = null;   // AnalyserNode
let rbPitchInterval   = null;   // polling interval
let rbPitchHistory    = [];     // recent detected MIDI note numbers
let rbPitchLocked     = false;  // true once key is detected and set
let rbPitchActive     = false;  // true while pitch detection is running

// MIDI note number → note name (chromatic)
const RB_NOTE_NAMES_CHROMATIC = ['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B'];

// Scale degree offsets from root for major scale
// degree: 1=0, 2=2, 3=4, 4=5, 5=7, 6=9, 7=11
const RB_MAJOR_DEGREE_OFFSETS = [0, 0, 2, 4, 5, 7, 9, 11]; // index by degree (1-based)

// Start pitch detection on the same mic stream as Vosk
function rbStartPitchDetection(stream) {
  if (rbPitchActive || !stream) return;
  try {
    rbPitchCtx      = new AudioContext();
    rbPitchSource   = rbPitchCtx.createMediaStreamSource(stream);
    rbPitchAnalyser = rbPitchCtx.createAnalyser();
    rbPitchAnalyser.fftSize = 2048;
    rbPitchSource.connect(rbPitchAnalyser);
    rbPitchHistory  = [];
    rbPitchLocked   = false;
    rbPitchActive   = true;

    // Poll pitch every 120ms
    rbPitchInterval = setInterval(() => {
      if (!rbPitchActive) return;
      const pitch = _rbDetectPitch();
      if (pitch && pitch > 0) {
        // Convert frequency to MIDI note number
        const midiNote = Math.round(12 * Math.log2(pitch / 440) + 69);
        // Only keep notes in singing range (C2=36 to C6=84)
        if (midiNote >= 36 && midiNote <= 84) {
          // Avoid duplicates — only add if different from last note
          // AND hold for at least 2 consecutive readings (240ms) for stability
          const last = rbPitchHistory[rbPitchHistory.length - 1];
          if (last !== midiNote) {
            rbPitchHistory.push(midiNote);
            if (rbPitchHistory.length > 30) rbPitchHistory.shift();
            // Wait until we have at least 9 notes before attempting match
            if (!rbPitchLocked && rbPitchHistory.length >= 9) {
              _rbTryMatchFingerprint();
            }
          }
        }
      }
    }, 120);

    console.log('[Rubato] Pitch detection started');
  } catch(e) {
    console.warn('[Rubato] Pitch detection failed to start:', e.message);
  }
}

// Stop pitch detection
function rbStopPitchDetection() {
  rbPitchActive = false;
  if (rbPitchInterval) { clearInterval(rbPitchInterval); rbPitchInterval = null; }
  try { if (rbPitchSource)   rbPitchSource.disconnect();  } catch(e) {}
  try { if (rbPitchAnalyser) rbPitchAnalyser.disconnect(); } catch(e) {}
  try { if (rbPitchCtx)      rbPitchCtx.close();          } catch(e) {}
  rbPitchCtx = null; rbPitchSource = null; rbPitchAnalyser = null;
  rbPitchHistory = [];
  console.log('[Rubato] Pitch detection stopped');
}

// Autocorrelation-based pitch detection from analyser buffer
function _rbDetectPitch() {
  if (!rbPitchAnalyser) return null;
  const bufLen = rbPitchAnalyser.fftSize;
  const buf    = new Float32Array(bufLen);
  rbPitchAnalyser.getFloatTimeDomainData(buf);

  // Check if there is enough signal (RMS check)
  let rms = 0;
  for (let i = 0; i < bufLen; i++) rms += buf[i] * buf[i];
  rms = Math.sqrt(rms / bufLen);
  if (rms < 0.01) return null; // silence — skip

  // Autocorrelation
  const sampleRate = rbPitchCtx.sampleRate;
  const corr       = new Float32Array(bufLen);
  for (let lag = 0; lag < bufLen; lag++) {
    let sum = 0;
    for (let i = 0; i < bufLen - lag; i++) sum += buf[i] * buf[i + lag];
    corr[lag] = sum;
  }

  // Find first peak after initial dip (skip lag=0 which is always highest)
  const minLag = Math.floor(sampleRate / 1000); // ~1000Hz max
  const maxLag = Math.floor(sampleRate / 60);   // ~60Hz min (low singing)
  let   bestLag = -1, bestVal = -Infinity;

  // Find where correlation dips below half of corr[0] first
  let dipped = false;
  for (let lag = minLag; lag < maxLag; lag++) {
    if (!dipped && corr[lag] < corr[0] * 0.5) dipped = true;
    if (dipped && corr[lag] > bestVal) {
      bestVal = corr[lag];
      bestLag = lag;
    }
  }

  if (bestLag < 1) return null;
  return sampleRate / bestLag;
}

// Try to match recent pitch history against song fingerprints
function _rbTryMatchFingerprint() {
  // Build interval sequence from recent MIDI notes
  // Use pitch class only (mod 12) to be octave-independent
  const notes     = rbPitchHistory.map(n => n % 12);
  const intervals = [];
  for (let i = 1; i < notes.length; i++) {
    let diff = notes[i] - notes[i-1];
    // Normalize to -6..+6 range (shortest interval)
    if (diff > 6)  diff -= 12;
    if (diff < -6) diff += 12;
    intervals.push(diff);
  }

  for (const song of RB_SONG_FINGERPRINTS) {
    const fp       = song.intervals;
    const minMatch = Math.min(8, fp.length); // need at least 8 interval matches

    // Slide the fingerprint across our interval history
    for (let start = 0; start <= intervals.length - minMatch; start++) {
      let matches = 0;
      let compared = 0;
      for (let i = 0; i < fp.length && start + i < intervals.length; i++) {
        compared++;
        // Allow ±1 semitone tolerance for singing imprecision
        if (Math.abs(intervals[start + i] - fp[i]) <= 1) matches++;
      }

      // Need at least 8 comparisons AND 80% match rate
      if (compared < 8) continue;
      const matchPct = matches / compared;
      if (matchPct >= 0.80) {
        // Good match — now determine the key from the first matched note
        // The first pitch in the matched window corresponds to degree[0] of the song
        const firstNotePC  = notes[start] % 12; // pitch class of first matched note
        const firstDegree  = song.degrees[0];   // scale degree of that note
        // Root = firstNotePC - offset of that degree in major scale
        const degreeOffset = RB_MAJOR_DEGREE_OFFSETS[firstDegree] || 0;
        let   rootPC       = ((firstNotePC - degreeOffset) % 12 + 12) % 12;

        const detectedKey  = RB_NOTE_NAMES_CHROMATIC[rootPC];
        const semitones    = rootPC; // C=0, Db=1, D=2...

        console.log('[Rubato] 🎵 Detected song:', song.name, '— Key:', detectedKey, '(' + Math.round(matchPct*100) + '% match)');

        // Auto-set the key in Rubato Mode
        rbTranspose    = semitones;
        rbPitchLocked  = true;
        rbKeyDetecting = false; // stop detecting — key is locked
        rbStopPitchDetection();
        renderRubatoCard();
        showNotification('🎵 Key locked: ' + detectedKey + ' — ' + song.name);
        return;
      }
    }
  }
}

// Try Again — fade out current music, reset detection, resume listening
async function rbTryAgainKeyDetection() {
  // Fade out current chunk gracefully
  if (rbPlaying) {
    if (rbGain) {
      rbGain.gain.setTargetAtTime(0, AC.currentTime, 0.3);
      setTimeout(() => {
        rbStopCurrent();
        if (rbGain) rbGain.gain.setTargetAtTime(1.0, AC.currentTime, 0.1);
      }, 600);
    } else {
      rbStopCurrent();
    }
  }

  // Reset key detection state
  rbPitchLocked  = false;
  rbPitchHistory = [];
  rbKeyDetecting = true;

  // Restart pitch detection on existing mic stream if available
  rbStopPitchDetection();
  const stream = rbMicStream || null;
  if (stream) {
    rbStartPitchDetection(stream);
    showNotification('🎵 Try Again — keep singing, VWB is listening for the key...');
  } else {
    // Need to open mic again
    try {
      const constraints = {
        audio: rbMicDeviceId
          ? { deviceId: { exact: rbMicDeviceId }, echoCancellation: true, noiseSuppression: true }
          : { echoCancellation: true, noiseSuppression: true },
        video: false
      };
      const newStream = await navigator.mediaDevices.getUserMedia(constraints);
      rbStartPitchDetection(newStream);
      showNotification('🎵 Try Again — keep singing, VWB is listening for the key...');
    } catch(e) {
      rbKeyDetecting = false;
      showNotification('❌ Microphone access denied');
    }
  }

  renderRubatoCard();
}

// Reset key detection so it can detect again
function rbResetKeyDetection() {
  rbPitchLocked  = false;
  rbPitchHistory = [];
  rbKeyDetecting = false;
  rbStopPitchDetection();
  showNotification('🎵 Key detection cleared');
  renderRubatoCard();
  console.log('[Rubato] Key detection reset');
}

// Uses the Web Audio API getUserMedia path that VWB's Armor Bearer
// VAD already uses successfully. Vosk runs entirely in the browser
// as WebAssembly — no internet, no Google, no external tools.
// Model downloads once (~40MB) then is cached permanently.

let rbMicDeviceId  = '';           // '' = system default
let rbMicLabel     = 'Default Mic';
let rbMicStream    = null;         // active MediaStream
let rbVoskModel    = null;         // loaded Vosk model
let rbVoskRec      = null;         // Vosk recognizer instance
let rbVoskCtx      = null;         // AudioContext for Vosk
let rbVoskSource   = null;         // MediaStreamAudioSourceNode
let rbVoskProc     = null;         // ScriptProcessorNode
let rbVoskReady    = false;        // true when model is loaded

// ── Vosk Model Loader ─────────────────────────────────────────
async function rbLoadVoskModel() {
  if (rbVoskReady) return true;
  if (typeof Vosk === 'undefined') {
    console.warn('[Rubato] Vosk not loaded — check script tag in index.html');
    return false;
  }
  try {
    showNotification('⏳ Loading speech model (one-time setup)…');
    console.log('[Rubato] Loading Vosk model...');

    // Use the small English model — 40MB, downloads once, cached by browser
    const MODEL_URL = 'https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip';

    rbVoskModel = await Vosk.createModel(MODEL_URL);
    rbVoskReady = true;
    showNotification('✅ Speech model ready');
    console.log('[Rubato] Vosk model loaded successfully');
    return true;
  } catch(e) {
    console.error('[Rubato] Vosk model load failed:', e.message);
    showNotification('❌ Speech model failed to load: ' + e.message);
    return false;
  }
}

// ── Key Detection Toggle (separate from word listening) ────────
async function rbToggleKeyDetection() {
  if (rbKeyDetecting) {
    // Stop key detection
    rbKeyDetecting = false;
    rbStopPitchDetection();
    renderRubatoCard();
    showNotification('🎵 Key detection stopped');
    return;
  }

  // Start key detection — needs mic open
  rbKeyDetecting = true;

  // If already listening for words, reuse existing mic stream
  if (rbListening && rbMicStream) {
    rbStartPitchDetection(rbMicStream);
    renderRubatoCard();
    showNotification('🎵 Key detection active — sing the melody');
    return;
  }

  // Otherwise open mic just for pitch detection
  try {
    const constraints = {
      audio: rbMicDeviceId
        ? { deviceId: { exact: rbMicDeviceId }, echoCancellation: true, noiseSuppression: true }
        : { echoCancellation: true, noiseSuppression: true },
      video: false
    };
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    rbStartPitchDetection(stream);
    renderRubatoCard();
    showNotification('🎵 Key detection active — sing the melody');
  } catch(e) {
    rbKeyDetecting = false;
    showNotification('❌ Microphone access denied');
  }
}

// Reset key detection
// ── Start Listening ───────────────────────────────────────────
async function rbStartListening() {
  if (rbListening) { rbStopListening(); return; }
  if (!rbPhrases.length) { showNotification('⚠ Load lyrics first'); return; }

  // Step 1: Load Vosk model if not already loaded
  const modelReady = await rbLoadVoskModel();
  if (!modelReady) {
    showNotification('❌ Speech model not ready — check internet for first-time setup');
    return;
  }

  // Step 2: Open microphone using same getUserMedia as Armor Bearer VAD
  try {
    const constraints = {
      audio: rbMicDeviceId
        ? { deviceId: { exact: rbMicDeviceId }, echoCancellation: true, noiseSuppression: true }
        : { echoCancellation: true, noiseSuppression: true },
      video: false
    };
    rbMicStream = await navigator.mediaDevices.getUserMedia(constraints);
    console.log('[Rubato] Microphone opened:', rbMicLabel);
  } catch(e) {
    showNotification('❌ Microphone access denied — check System Settings > Privacy > Microphone');
    console.error('[Rubato] getUserMedia failed:', e.message);
    return;
  }

  // Step 3: Create Vosk recognizer and connect to microphone stream
  try {
    const sampleRate = 16000;

    // Build word list from trigger words for faster, more accurate recognition
    const triggerWords = rbPhrases
      .filter(p => p.firstWord)
      .map(p => p.firstWord.toLowerCase());
    const grammar = JSON.stringify([...new Set(triggerWords), '[unk]']);

    rbVoskRec = new rbVoskModel.KaldiRecognizer(sampleRate, grammar);
    rbVoskRec.setWords(true);

    // Listen for results from Vosk recognizer
    rbVoskRec.on('result', (message) => {
      if (!rbListening) return;
      const text = message.result && message.result.text ? message.result.text.trim() : '';
      if (text.length > 0) {
        console.log('[Rubato] Vosk heard:', text);
        _rbMatchTranscript(text.toLowerCase());
      }
    });

    rbVoskRec.on('partialresult', (message) => {
      if (!rbListening) return;
      const partial = message.result && message.result.partial ? message.result.partial.trim() : '';
      if (partial.length > 2) {
        console.log('[Rubato] Vosk partial:', partial);
        _rbMatchTranscript(partial.toLowerCase());
      }
    });

    // Wire: mic stream → AudioContext → ScriptProcessor → Vosk
    rbVoskCtx    = new AudioContext({ sampleRate });
    rbVoskSource = rbVoskCtx.createMediaStreamSource(rbMicStream);
    rbVoskProc   = rbVoskCtx.createScriptProcessor(4096, 1, 1);

    rbVoskProc.onaudioprocess = (e) => {
      if (!rbListening || !rbVoskRec) return;
      try {
        // vosk-browser accepts the AudioBuffer directly
        rbVoskRec.acceptWaveform(e.inputBuffer);
      } catch(err) {
        // ignore transient errors during processing
      }
    };

    rbVoskSource.connect(rbVoskProc);
    rbVoskProc.connect(rbVoskCtx.destination);

    // If key detection is also active, start pitch detection on same stream
    if (rbKeyDetecting) {
      rbStartPitchDetection(rbMicStream);
    }

    rbListening = true;
    renderRubatoCard();
    showNotification('🎙 Rubato listening (offline) — ' + rbMicLabel);
    console.log('[Rubato] Vosk listening started on:', rbMicLabel);

  } catch(e) {
    console.error('[Rubato] Vosk start error:', e.message);
    showNotification('❌ Could not start speech recognition: ' + e.message);
    _rbReleaseMic();
  }
}

// ── Stop Listening ────────────────────────────────────────────
function rbStopListening() {
  rbListening = false;
  rbStopPitchDetection();
  try { if (rbVoskProc)   { rbVoskProc.disconnect();   rbVoskProc   = null; } } catch(e) {}
  try { if (rbVoskSource) { rbVoskSource.disconnect();  rbVoskSource = null; } } catch(e) {}
  try { if (rbVoskCtx)    { rbVoskCtx.close();          rbVoskCtx    = null; } } catch(e) {}
  try { if (rbVoskRec)    { rbVoskRec.remove();         rbVoskRec    = null; } } catch(e) {}
  _rbReleaseMic();
  renderRubatoCard();
  console.log('[Rubato] Vosk listening stopped');
}

function _rbReleaseMic() {
  if (rbMicStream) {
    rbMicStream.getTracks().forEach(t => t.stop());
    rbMicStream = null;
  }
}

// ── Mic Device Selection ──────────────────────────────────────
function rbSetMicDevice(deviceId, label) {
  rbMicDeviceId = deviceId || '';
  rbMicLabel    = label   || 'Default Mic';
  if (rbListening) {
    rbStopListening();
    setTimeout(() => rbStartListening(), 300);
  }
  console.log('[Rubato] Mic device set:', rbMicLabel);
}

async function rbPopulateMicDevices(selectElementId) {
  try {
    await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
    const devices = await navigator.mediaDevices.enumerateDevices();
    const mics    = devices.filter(d => d.kind === 'audioinput');
    const sel     = document.getElementById(selectElementId);
    if (!sel) return;
    sel.innerHTML = '<option value="">Default Mic</option>';
    mics.forEach(d => {
      const opt    = document.createElement('option');
      opt.value    = d.deviceId;
      opt.text     = d.label || ('Microphone ' + d.deviceId.slice(0, 6));
      opt.selected = d.deviceId === rbMicDeviceId;
      sel.appendChild(opt);
    });
    console.log('[Rubato] Found', mics.length, 'microphone devices');
  } catch(e) {
    console.warn('[Rubato] Could not enumerate mic devices:', e.message);
  }
}

// Called by future Whisper IPC integration
function rbOnWhisperTranscript(transcript) {
  if (!rbListening) return;
  console.log('[Rubato] Transcript:', transcript);
  _rbMatchTranscript(transcript.toLowerCase().trim());
}

// Match recognized transcript against trigger words
function _rbMatchTranscript(transcript) {
  const heard = transcript.split(/\s+/).map(w => w.replace(/[^a-z0-9]/g, ''));

  // Look ahead linearly from current position (up to 4 phrases ahead)
  const startSearch = Math.max(0, rbCurrentIdx + 1);

  for (let lookahead = 0; lookahead <= 4; lookahead++) {
    const checkIdx = startSearch + lookahead;
    if (checkIdx >= rbPhrases.length) break;
    const phrase = rbPhrases[checkIdx];
    if (!phrase.trigger) continue;
    // Match on the first word of the phrase (the trigger word)
    if (heard.includes(phrase.firstWord)) {
      rbPlayChunk(checkIdx);
      return;
    }
  }

  // Not found nearby — search whole song for repeated sections (chorus etc.)
  for (let i = 0; i < rbPhrases.length; i++) {
    if (i === rbCurrentIdx) continue;
    const phrase = rbPhrases[i];
    if (!phrase.trigger) continue;
    if (heard.includes(phrase.firstWord)) {
      rbPlayChunk(i);
      return;
    }
  }
}

// ── Manual Controls ────────────────────────────────────────────
function rbManualNext() {
  const next = rbCurrentIdx + 1;
  if (next >= rbPhrases.length) return;
  // Find next phrase that has a trigger
  for (let i = next; i < rbPhrases.length; i++) {
    if (rbPhrases[i].trigger) { rbPlayChunk(i); return; }
  }
}

function rbManualPrev() {
  const prev = rbCurrentIdx - 1;
  if (prev < 0) return;
  for (let i = prev; i >= 0; i--) {
    if (rbPhrases[i].trigger) { rbPlayChunk(i); return; }
  }
}

function rbManualTrigger(idx) {
  rbPlayChunk(idx);
  // Song Map stays open — rbSongMapOpen is not changed here
}

function rbReset() {
  rbStopCurrent();
  rbCurrentIdx = -1;
  renderRubatoCard();
}

// ── Render ─────────────────────────────────────────────────────
function renderRubatoCard() {
  const wrap = document.getElementById('rbWrap');
  if (!wrap) return;

  const keyName    = rbGetKeyName();
  const hasChunks  = Object.keys(rbChunkFiles).length > 0;
  const hasLyrics  = rbPhrases.length > 0;
  const ready      = (hasChunks && hasLyrics) || rbPackLoaded;

  // Phrase display — previous, current, next, coming up
  const prevPhrase = rbCurrentIdx > 0 ? rbPhrases[rbCurrentIdx - 1] : null;
  const curPhrase  = rbCurrentIdx >= 0 ? rbPhrases[rbCurrentIdx] : null;
  const nextPhrase = rbCurrentIdx + 1 < rbPhrases.length ? rbPhrases[rbCurrentIdx + 1] : null;
  const upcoming   = rbCurrentIdx + 2 < rbPhrases.length ? rbPhrases[rbCurrentIdx + 2] : null;

  // Find next actionable phrase (one with a trigger)
  let nextTriggerIdx = -1;
  for (let i = rbCurrentIdx + 1; i < rbPhrases.length; i++) {
    if (rbPhrases[i].trigger) { nextTriggerIdx = i; break; }
  }

  const btnStyle = `font-family:'Outfit',sans-serif;font-size:.7rem;font-weight:600;
    padding:.25rem .55rem;border-radius:6px;cursor:pointer;transition:all .15s;`;

  // Reverb FX panel
  const hallActive  = rbReverbType === 'hall';
  const plateActive = rbReverbType === 'plate';
  const fxPanel = `
    <div style="margin-top:.5rem;">
      <button onclick="rbFxOpen=!rbFxOpen;renderRubatoCard();"
        style="${btnStyle}border:1px solid ${rbFxOpen ? 'rgba(255,136,68,.5)' : 'var(--border)'};
               background:${rbFxOpen ? 'rgba(255,136,68,.1)' : 'none'};
               color:${rbFxOpen ? '#FF8844' : 'var(--text-dim)'};">
        FX ${rbFxOpen ? '▾' : '▸'}
      </button>
    </div>
    ${rbFxOpen ? `
    <div style="margin-top:.35rem;padding:.4rem .55rem;border-radius:7px;
                border:1px solid rgba(255,136,68,.18);background:rgba(255,136,68,.04);
                display:flex;flex-direction:column;gap:.35rem;">
      <div style="display:flex;align-items:center;gap:.4rem;">
        <span style="font-size:.65rem;color:var(--text-dim);min-width:50px;">Reverb</span>
        <button onclick="rbSetReverbType(rbReverbType==='hall'?'none':'hall')"
          style="${btnStyle}border:1px solid ${hallActive ? '#7eb8d4' : 'var(--border)'};
                 background:${hallActive ? 'rgba(126,184,212,.25)' : 'none'};
                 color:${hallActive ? '#7eb8d4' : 'var(--text-dim)'};">Hall</button>
        <button onclick="rbSetReverbType(rbReverbType==='plate'?'none':'plate')"
          style="${btnStyle}border:1px solid ${plateActive ? '#d4a07e' : 'var(--border)'};
                 background:${plateActive ? 'rgba(212,160,126,.25)' : 'none'};
                 color:${plateActive ? '#d4a07e' : 'var(--text-dim)'};">Plate</button>
        <span style="font-size:.6rem;color:var(--text-dim);">${rbReverbType === 'none' ? '— off' : ''}</span>
      </div>
      ${rbReverbType !== 'none' ? `
      <div style="display:flex;align-items:center;gap:.5rem;">
        <span style="font-size:.65rem;color:var(--text-dim);min-width:50px;">Amount</span>
        <input type="range" min="0" max="100" value="${rbReverbAmount}" step="1"
          style="-webkit-appearance:none;flex:1;height:3px;border-radius:2px;background:var(--bg-primary);"
          oninput="rbSetReverbAmount(this.value)">
        <span id="rbRevAmtVal"
          style="font-family:'Space Mono',monospace;font-size:.65rem;color:var(--text-dim);min-width:30px;text-align:right;">
          ${rbReverbAmount}%
        </span>
      </div>` : ''}
    </div>` : ''}
  `;

  wrap.innerHTML = `

    ${rbPackLoaded ? `
    <!-- Song Pack Info Banner -->
    <div style="display:flex;align-items:center;gap:.75rem;padding:.6rem .75rem;
                background:linear-gradient(135deg,rgba(249,115,22,.08),rgba(251,191,36,.05));
                border:1px solid rgba(249,115,22,.2);border-radius:8px;margin-bottom:.75rem;">
      ${rbArtistPhoto ? `
      <img src="${rbArtistPhoto}" alt="${rbArtistName}"
        style="width:38px;height:38px;border-radius:50%;object-fit:cover;
               border:2px solid rgba(249,115,22,.4);flex-shrink:0;">` : `
      <div style="width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,var(--orange),var(--gold));
                  display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0;">🎹</div>`}
      <div style="flex:1;min-width:0;">
        <div style="font-size:.95rem;font-weight:700;color:var(--text-primary);
                    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${rbSongTitle}</div>
        <div style="font-size:.65rem;color:var(--text-dim);text-transform:uppercase;
                    letter-spacing:.08em;">${rbArtistRole} &nbsp;·&nbsp; ${rbArtistName}</div>
      </div>
      <button onclick="rbLoadVwbPack()"
        style="${btnStyle}border:1px solid var(--border);background:none;
               color:var(--text-dim);font-size:.65rem;">↺ Change</button>
    </div>` : ''}

    <!-- Setup row -->
    <div style="display:flex;flex-wrap:wrap;gap:.5rem;align-items:flex-start;margin-bottom:.75rem;">

      <!-- Load VWB Pack (primary) OR legacy loaders -->
      <div style="display:flex;flex-direction:column;gap:.25rem;">
        <span style="font-size:.65rem;color:var(--text-dim);text-transform:uppercase;letter-spacing:.05em;">Song Pack</span>
        <button onclick="rbLoadVwbPack()"
          style="${btnStyle}border:1px solid ${rbPackLoaded ? 'var(--orange)' : 'var(--border)'};
                 background:${rbPackLoaded ? 'rgba(249,115,22,.1)' : 'none'};
                 color:${rbPackLoaded ? 'var(--orange)' : 'var(--text-dim)'};">
          ${rbPackLoaded ? '✓ ' + rbPhrases.length + ' phrases' : '📦 Load .vwb Pack'}
        </button>
      </div>

      ${!rbPackLoaded ? `
      <!-- Legacy: Load Lyrics -->
      <div style="display:flex;flex-direction:column;gap:.25rem;">
        <span style="font-size:.65rem;color:var(--text-dim);text-transform:uppercase;letter-spacing:.05em;">Lyrics File</span>
        <button onclick="rbLoadLyricsFile()"
          style="${btnStyle}border:1px solid ${hasLyrics && !rbPackLoaded ? 'var(--accent)' : 'var(--border)'};
                 background:${hasLyrics && !rbPackLoaded ? 'rgba(64,224,208,.1)' : 'none'};
                 color:${hasLyrics && !rbPackLoaded ? 'var(--accent)' : 'var(--text-dim)'};">
          ${hasLyrics && !rbPackLoaded ? '✓ ' + rbPhrases.length + ' phrases' : '📄 Load Lyrics (.txt)'}
        </button>
      </div>

      <!-- Legacy: Load Chunks -->
      <div style="display:flex;flex-direction:column;gap:.25rem;">
        <span style="font-size:.65rem;color:var(--text-dim);text-transform:uppercase;letter-spacing:.05em;">MIDI Chunks</span>
        <button onclick="rbSelectChunkFolder()"
          style="${btnStyle}border:1px solid ${hasChunks ? '#FF8844' : 'var(--border)'};
                 background:${hasChunks ? 'rgba(255,136,68,.1)' : 'none'};
                 color:${hasChunks ? '#FF8844' : 'var(--text-dim)'};">
          ${hasChunks ? '✓ ' + Object.keys(rbChunkFiles).length + ' chunks' : '🎹 Load MIDI Chunks'}
        </button>
      </div>` : ''}

      <!-- Key / Transpose -->
      <div style="display:flex;flex-direction:column;gap:.25rem;">
        <span style="font-size:.65rem;color:var(--text-dim);text-transform:uppercase;letter-spacing:.05em;">Key
          ${rbPitchLocked ? '<span style="color:#44dd88;font-size:.6rem;margin-left:.3rem;">🎵 Auto</span>' : ''}
        </span>
        <div style="display:flex;align-items:center;gap:.3rem;">
          <button onclick="rbSetTranspose(-1)"
            style="${btnStyle}border:1px solid var(--border);background:none;color:var(--text-dim);padding:.2rem .4rem;">−</button>
          <span style="font-family:'Space Mono',monospace;font-size:.9rem;font-weight:700;
                       color:${rbPitchLocked ? '#44dd88' : 'var(--orange)'};min-width:28px;text-align:center;">${keyName}</span>
          <button onclick="rbSetTranspose(1)"
            style="${btnStyle}border:1px solid var(--border);background:none;color:var(--text-dim);padding:.2rem .4rem;">+</button>
          ${rbPitchLocked ? `<button onclick="rbResetKeyDetection()" title="Reset key detection"
            style="${btnStyle}border:1px solid rgba(68,221,136,.3);background:none;color:#44dd88;padding:.2rem .35rem;font-size:.65rem;">↺</button>` : ''}
        </div>
      </div>

      <!-- Octave -->
      <div style="display:flex;flex-direction:column;gap:.25rem;">
        <span style="font-size:.65rem;color:var(--text-dim);text-transform:uppercase;letter-spacing:.05em;">Octave</span>
        <div style="display:flex;align-items:center;gap:.3rem;">
          <button onclick="rbSetOctave(-1)"
            style="${btnStyle}border:1px solid var(--border);background:none;color:var(--text-dim);padding:.2rem .4rem;">−</button>
          <span style="font-family:'Space Mono',monospace;font-size:.9rem;font-weight:700;
                       color:var(--text-secondary);min-width:22px;text-align:center;">
            ${rbOctave === 0 ? '0' : (rbOctave > 0 ? '+' + rbOctave : rbOctave)}
          </span>
          <button onclick="rbSetOctave(1)"
            style="${btnStyle}border:1px solid var(--border);background:none;color:var(--text-dim);padding:.2rem .4rem;">+</button>
        </div>
      </div>

      <!-- Confidence -->
      <div style="display:flex;flex-direction:column;gap:.25rem;min-width:120px;">
        <span style="font-size:.65rem;color:var(--text-dim);text-transform:uppercase;letter-spacing:.05em;">
          Confidence
        </span>
        <div style="display:flex;align-items:center;gap:.4rem;">
          <span style="font-size:.6rem;color:var(--text-dim);">Low</span>
          <input type="range" min="0.1" max="0.8" step="0.05" value="${rbConfidence}"
            style="-webkit-appearance:none;width:80px;height:3px;border-radius:2px;background:var(--bg-primary);"
            oninput="rbConfidence=parseFloat(this.value);document.getElementById('rbConfVal').textContent=Math.round(this.value*100)+'%'">
          <span style="font-size:.6rem;color:var(--text-dim);">High</span>
          <span id="rbConfVal"
            style="font-family:'Space Mono',monospace;font-size:.65rem;color:var(--text-dim);">
            ${Math.round(rbConfidence * 100)}%
          </span>
        </div>
      </div>

      <!-- Microphone Input Selector -->
      <div style="display:flex;flex-direction:column;gap:.25rem;min-width:160px;">
        <span style="font-size:.65rem;color:var(--text-dim);text-transform:uppercase;letter-spacing:.05em;">
          Mic Input
        </span>
        <div style="display:flex;align-items:center;gap:.3rem;">
          <select id="rbMicSelect"
            onchange="rbSetMicDevice(this.value, this.options[this.selectedIndex].text)"
            style="flex:1;background:var(--bg-primary);border:1px solid var(--border);
                   color:var(--text-primary);padding:.18rem .35rem;border-radius:5px;
                   font-size:.65rem;font-family:'Outfit',sans-serif;">
            <option value="">${rbMicLabel || 'Default Mic'}</option>
          </select>
          <button onclick="rbPopulateMicDevices('rbMicSelect')"
            title="Refresh microphone list"
            style="${btnStyle}border:1px solid var(--border);background:none;
                   color:var(--text-dim);padding:.18rem .4rem;font-size:.75rem;">
            ↻
          </button>
        </div>
      </div>

    </div>

    <!-- FX Panel -->
    ${fxPanel}

    ${ready ? `
    <!-- Live Performance Area -->
    <div style="margin-top:.75rem;padding-top:.75rem;border-top:1px solid var(--border);">

      <!-- Transport controls -->
      <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.6rem;flex-wrap:wrap;">

        <!-- Listen for Words button -->
        <button onclick="rbStartListening()"
          title="${rbListening ? 'Stop word listening' : 'Start voice listening — triggers MIDI chunks from sung words'}"
          style="${btnStyle}
                 border:1px solid ${rbListening ? '#44cc88' : 'var(--border)'};
                 background:${rbListening ? 'rgba(68,204,136,.15)' : 'none'};
                 color:${rbListening ? '#44cc88' : 'var(--text-dim)'};
                 ${rbListening ? 'box-shadow:0 0 8px rgba(68,204,136,.3);' : ''}">
          ${rbListening ? '🎙 Listening…' : '🎙 Listen'}
        </button>

        <!-- Detect Key button — separate from word listening -->
        <button onclick="${rbPitchLocked ? 'rbTryAgainKeyDetection()' : 'rbToggleKeyDetection()'}"
          title="${rbPitchLocked ? 'Key is locked — click to try again' : rbKeyDetecting ? 'Stop key detection' : 'Auto-detect key from sung melody'}"
          style="${btnStyle}
                 border:1px solid ${rbPitchLocked ? 'rgba(68,221,136,.4)' : rbKeyDetecting ? '#fbbf24' : 'var(--border)'};
                 background:${rbPitchLocked ? 'rgba(68,221,136,.08)' : rbKeyDetecting ? 'rgba(251,191,36,.12)' : 'none'};
                 color:${rbPitchLocked ? '#44dd88' : rbKeyDetecting ? '#fbbf24' : 'var(--text-dim)'};
                 ${rbKeyDetecting ? 'box-shadow:0 0 8px rgba(251,191,36,.2);' : ''}">
          ${rbPitchLocked ? '✓ Key Locked — Try Again?' : rbKeyDetecting ? '🎵 Detecting…' : '🎵 Detect Key'}
        </button>

        <button onclick="rbManualPrev()"
          title="Previous phrase"
          style="${btnStyle}border:1px solid var(--border);background:none;color:var(--text-dim);">◀ Prev</button>
        <button onclick="rbManualNext()"
          title="Trigger next phrase manually"
          style="${btnStyle}border:1px solid var(--border);background:none;color:var(--text-dim);">Next ▶</button>
        <button onclick="rbStopCurrent();renderRubatoCard();"
          style="${btnStyle}border:1px solid var(--border);background:none;color:var(--text-dim);">■ Stop</button>
        <button onclick="rbReset()"
          style="${btnStyle}border:1px solid var(--border);background:none;color:var(--text-dim);">↺ Reset</button>
        <span style="font-size:.65rem;color:var(--text-dim);margin-left:auto;">
          ${rbCurrentIdx >= 0 ? (rbCurrentIdx + 1) + ' / ' + rbPhrases.length : '—'}
        </span>
      </div>

      <!-- Phrase display -->
      <div style="display:flex;flex-direction:column;gap:.3rem;">

        ${prevPhrase ? `
        <!-- Just played -->
        <div style="padding:.35rem .6rem;border-radius:7px;background:var(--bg-secondary);
                    border:1px solid var(--border);opacity:.45;">
          <div style="font-size:.58rem;color:var(--text-dim);margin-bottom:.1rem;">✓ JUST PLAYED</div>
          <div style="font-size:.8rem;color:var(--text-dim);">${prevPhrase.line}</div>
        </div>` : ''}

        ${curPhrase ? `
        <!-- Now playing -->
        <div style="padding:.45rem .6rem;border-radius:7px;
                    background:${rbPlaying ? 'rgba(64,224,208,.1)' : 'rgba(170,68,255,.08)'};
                    border:2px solid ${rbPlaying ? 'var(--accent)' : 'rgba(170,68,255,.3)'};
                    box-shadow:${rbPlaying ? '0 0 12px rgba(64,224,208,.2)' : 'none'};">
          <div style="font-size:.58rem;color:${rbPlaying ? 'var(--accent)' : 'var(--text-dim)'};margin-bottom:.1rem;">
            ${rbPlaying ? '▶ NOW PLAYING' : '● CURRENT'}
          </div>
          <div style="font-size:.88rem;font-weight:600;color:var(--text-primary);">${curPhrase.line}</div>
          ${curPhrase.trigger ? `<div style="font-size:.6rem;color:var(--text-dim);margin-top:.15rem;">
            trigger: <span style="color:var(--orange);">${curPhrase.trigger}</span>
          </div>` : ''}
        </div>` : `
        <!-- No phrase playing yet -->
        <div style="padding:.6rem;border-radius:7px;background:var(--bg-secondary);
                    border:1px dashed var(--border);text-align:center;">
          <div style="font-size:.75rem;color:var(--text-dim);">
            Use Next ▶ or click Trigger to play each phrase
          </div>
        </div>`}

        ${nextTriggerIdx >= 0 ? `
        <!-- Up next — with manual trigger button -->
        <div style="padding:.4rem .6rem;border-radius:7px;background:rgba(255,136,68,.05);
                    border:1px solid rgba(255,136,68,.2);display:flex;align-items:center;gap:.5rem;">
          <div style="flex:1;">
            <div style="font-size:.58rem;color:#FF8844;margin-bottom:.1rem;">⏭ UP NEXT</div>
            <div style="font-size:.82rem;color:var(--text-secondary);">${rbPhrases[nextTriggerIdx].line}</div>
          </div>
          <button onclick="rbManualTrigger(${nextTriggerIdx})"
            title="Trigger this phrase now"
            style="${btnStyle}border:1px solid #FF8844;background:rgba(255,136,68,.15);
                   color:#FF8844;white-space:nowrap;padding:.3rem .55rem;">
            ▶ Trigger
          </button>
        </div>` : ''}

        ${upcoming ? `
        <!-- Coming up -->
        <div style="padding:.3rem .6rem;border-radius:7px;background:var(--bg-secondary);
                    border:1px solid var(--border);opacity:.6;">
          <div style="font-size:.58rem;color:var(--text-dim);margin-bottom:.05rem;">── COMING UP</div>
          <div style="font-size:.75rem;color:var(--text-dim);">${upcoming.line}</div>
        </div>` : ''}

      </div>

      <!-- Phrase list (scrollable) -->
      ${rbPhrases.length > 0 ? `
      <div style="margin-top:.6rem;">
        <button onclick="rbSongMapOpen=!rbSongMapOpen;renderRubatoCard();"
          style="${btnStyle}border:1px solid var(--border);background:none;color:var(--text-dim);font-size:.65rem;">
          Song Map ${rbSongMapOpen ? '▾' : '▸'}
        </button>
        ${rbSongMapOpen ? `
        <div style="margin-top:.35rem;max-height:220px;overflow-y:auto;
              border:1px solid var(--border);border-radius:6px;padding:.3rem;">
          ${rbPhrases.map((p, i) => `
            <div onclick="rbManualTrigger(${i})"
              style="display:flex;align-items:center;gap:.4rem;padding:.25rem .35rem;border-radius:4px;
                     cursor:pointer;background:${i === rbCurrentIdx ? 'rgba(64,224,208,.1)' : 'none'};
                     border-left:2px solid ${i === rbCurrentIdx ? 'var(--accent)' : 'transparent'};
                     margin-bottom:.1rem;">
              <span style="font-size:.6rem;color:var(--text-dim);min-width:20px;">${i+1}</span>
              <span style="font-size:.72rem;color:${i === rbCurrentIdx ? 'var(--text-primary)' : 'var(--text-dim)'};">${p.line}</span>
              ${p.trigger ? `<span style="font-size:.58rem;color:var(--orange);margin-left:auto;">${p.trigger}</span>` : `<span style="font-size:.58rem;color:var(--text-dim);margin-left:auto;font-style:italic;">no trigger</span>`}
            </div>`).join('')}
        </div>` : ''}
      </div>` : ''}
    </div>` : `
    <!-- Not ready state -->
    <div style="margin-top:.75rem;padding:.75rem;border-radius:8px;background:var(--bg-secondary);
                border:1px dashed var(--border);text-align:center;">
      <div style="font-size:.75rem;color:var(--text-dim);">
        ${!hasLyrics && !hasChunks ? 'Load lyrics and MIDI chunks above to get started' :
          !hasLyrics ? 'Load a lyrics text file to continue' :
          'Load MIDI chunk files to continue'}
      </div>
    </div>`}
  `;
}

// ── Session Save/Restore ───────────────────────────────────────
function getRubatoState() {
  return {
    transpose:    rbTranspose,
    octave:       rbOctave,
    confidence:   rbConfidence,
    reverbType:   rbReverbType,
    reverbAmount: rbReverbAmount
  };
}

function restoreRubatoState(state) {
  if (!state) return;
  rbTranspose    = state.transpose    || 0;
  rbOctave       = state.octave       || 0;
  rbConfidence   = state.confidence   || 0.35;
  rbReverbType   = state.reverbType   || 'none';
  rbReverbAmount = state.reverbAmount !== undefined ? state.reverbAmount : 30;
  renderRubatoCard();
}
