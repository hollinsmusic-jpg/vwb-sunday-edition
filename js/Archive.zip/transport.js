// ═══════════════════════════════════════════════════════════════
//  Virtual Worship Band — Unified Transport Coordinator
//  Engine selector (Audio / MIDI), unified playback controls,
//  section jumping, timeline, and progress updates.
//  Depends on: state.js, audio-engine.js, midi-player.js,
//              midi-sections.js, ui.js
// ═══════════════════════════════════════════════════════════════

// ── Tempo Sync — MIDI engine keeps Song Info and MIDI player in sync ──

// Called when user changes tempo in Song Info (songTempo input)
function onSongTempoChange(val) {
  const bpm = parseInt(val) || 72;
  song.tempo = bpm;
  // If MIDI engine active, sync to MIDI BPM
  if (vwbActiveEngine === 'midi' && typeof setMidiBpm === 'function') {
    setMidiBpm(bpm);
  }
  if (typeof updMInfo === 'function') updMInfo();
}

// Called when MIDI tempo changes — syncs back to Song Info
function syncMidiTempoToSongInfo(bpm) {
  song.tempo = bpm;
  const el = document.getElementById('songTempo');
  if (el) el.value = bpm;
  // Also update Perform BPM display
  const perfTempo = document.getElementById('pTempo');
  if (perfTempo) perfTempo.textContent = bpm + ' BPM';
  if (typeof updMInfo === 'function') updMInfo();
}

// ── Active Engine State ────────────────────────────────────────
// 'audio' | 'midi' | 'organ'
let vwbActiveEngine = 'audio';

// ── Set Engine ─────────────────────────────────────────────────

function setVwbEngine(eng, notify = true) {
  const prev = vwbActiveEngine;
  vwbActiveEngine = (['audio','midi','organ'].includes(eng)) ? eng : 'audio';

  // Stop engines being deactivated
  if (prev === 'midi' && vwbActiveEngine !== 'midi') {
    if (typeof midiPlaying !== 'undefined' && midiPlaying) stopMidiPlay();
  }
  if (prev === 'audio' && vwbActiveEngine !== 'audio') {
    if (typeof playing !== 'undefined' && playing) doStop();
  }
  if (prev === 'organ' && vwbActiveEngine !== 'organ') {
    if (typeof abStop === 'function') abStop();
  }

  // Show/hide Setup page cards
  const audioCards    = document.getElementById('setupAudioCards');
  const midiCard      = document.getElementById('setupMidiCard');
  const organCard     = document.getElementById('setupOrganCard');
  const sectionCard   = document.getElementById('setupSectionCard');
  if (audioCards)  audioCards.style.display  = vwbActiveEngine === 'audio' ? '' : 'none';
  if (midiCard)    midiCard.style.display    = vwbActiveEngine === 'midi'  ? '' : 'none';
  if (organCard)   organCard.style.display   = vwbActiveEngine === 'organ' ? '' : 'none';
  if (sectionCard) sectionCard.style.display = vwbActiveEngine === 'organ' ? 'none' : '';

  // Update Setup page engine buttons
  _abUpdateSetupEngineBtns();

  // Update Perform page read-only engine label
  const uniLabel = document.getElementById('uniEngineLabel');
  if (uniLabel) {
    if (vwbActiveEngine === 'midi') {
      uniLabel.textContent        = '🎹 MIDI';
      uniLabel.style.borderColor  = 'var(--orange)';
      uniLabel.style.background   = 'rgba(255,136,68,.15)';
      uniLabel.style.color        = 'var(--orange)';
    } else if (vwbActiveEngine === 'organ') {
      uniLabel.textContent        = '🎹 Organ';
      uniLabel.style.borderColor  = '#AA44FF';
      uniLabel.style.background   = 'rgba(170,68,255,.15)';
      uniLabel.style.color        = '#AA44FF';
    } else {
      uniLabel.textContent        = '🎵 Audio';
      uniLabel.style.borderColor  = 'var(--accent)';
      uniLabel.style.background   = 'rgba(64,224,208,.15)';
      uniLabel.style.color        = 'var(--accent)';
    }
  }

  // Show/hide Organ Perform panel and transport controls
  const abPanel          = document.getElementById('abPerfPanel');
  const uniTransport     = document.getElementById('uniTransportControls');
  const uniOrganTransport= document.getElementById('uniOrganTransport');
  if (abPanel)           abPanel.style.display           = vwbActiveEngine === 'organ' ? '' : 'none';
  if (uniTransport)      uniTransport.style.display      = vwbActiveEngine === 'organ' ? 'none' : 'flex';
  if (uniOrganTransport) uniOrganTransport.style.display = vwbActiveEngine === 'organ' ? 'flex' : 'none';

  _uniUpdateTransportUI();
  uniUpdateMidiControls();

  if (notify) {
    const labels = { audio: '🎵 Audio Engine', midi: '🎹 MIDI Engine', organ: '🎹 Organ Engine' };
    showNotification(labels[vwbActiveEngine] + ' active');
  }
}

function _abUpdateSetupEngineBtns() {
  const sAudio = document.getElementById('setupEngBtnAudio');
  const sMidi  = document.getElementById('setupEngBtnMidi');
  const sOrgan = document.getElementById('setupEngBtnOrgan');
  if (sAudio) {
    sAudio.style.borderColor = vwbActiveEngine === 'audio' ? 'var(--accent)' : 'var(--border)';
    sAudio.style.background  = vwbActiveEngine === 'audio' ? 'rgba(64,224,208,.15)' : 'none';
    sAudio.style.color       = vwbActiveEngine === 'audio' ? 'var(--accent)' : 'var(--text-dim)';
  }
  if (sMidi) {
    sMidi.style.borderColor  = vwbActiveEngine === 'midi' ? 'var(--orange)' : 'var(--border)';
    sMidi.style.background   = vwbActiveEngine === 'midi' ? 'rgba(255,136,68,.15)' : 'none';
    sMidi.style.color        = vwbActiveEngine === 'midi' ? 'var(--orange)' : 'var(--text-dim)';
  }
  if (sOrgan) {
    sOrgan.style.borderColor = vwbActiveEngine === 'organ' ? '#AA44FF' : 'var(--border)';
    sOrgan.style.background  = vwbActiveEngine === 'organ' ? 'rgba(170,68,255,.15)' : 'none';
    sOrgan.style.color       = vwbActiveEngine === 'organ' ? '#AA44FF' : 'var(--text-dim)';
  }
}

// ── Unified Transport Commands ─────────────────────────────────

function uniTogglePlay() {
  if (AC.state === 'suspended') AC.resume();
  if (vwbActiveEngine === 'organ') {
    // Organ engine — trigger current level
    if (typeof abTrigger === 'function') abTrigger(abCurrentKey, abCurrentLevel);
    return;
  }
  if (vwbActiveEngine === 'midi') {
    if (typeof getMidiActive === 'function' && !getMidiActive()) {
      showNotification('⚠ No MIDI file loaded. Add a MIDI file in Song Setup first.');
      return;
    }
    toggleMidiPlay();
  } else {
    if (!stemCount() && !auxTracks.length) {
      showNotification('⚠ No audio loaded. Load stems in Song Setup first.');
      return;
    }
    togglePlay();
  }
  _uniUpdateTransportUI();
}

function uniStop() {
  if (vwbActiveEngine === 'organ') {
    if (typeof abStop === 'function') { abStop(); if (typeof renderArmorBearerPerform === 'function') renderArmorBearerPerform(); }
    return;
  }
  if (vwbActiveEngine === 'midi') {
    stopMidiPlay();
  } else {
    doStop();
  }
  _uniUpdateTransportUI();
}

function uniToggleSecLoop() {
  if (vwbActiveEngine === 'midi') {
    toggleMidiSectionLoop();
  } else {
    toggleSecLoop();
  }
  _uniUpdateTransportUI();
}

// ── Unified Section Jump ───────────────────────────────────────
// Always routes through queueSection which handles both engines.
// queueSection detects vwbActiveEngine and bridges to MIDI when needed.

function uniJumpSection(idx) {
  if (typeof queueSection === 'function') {
    queueSection(idx);
  }
}

// ── Unified Fade Out ───────────────────────────────────────────

let _fadeInterval  = null;
let _fadeActive    = false;

function uniFadeOut() {
  if (_fadeActive) return; // already fading
  const dur     = (typeof vwbFadeDuration !== 'undefined') ? vwbFadeDuration : 4;
  const steps   = 40;
  const stepMs  = (dur * 1000) / steps;
  _fadeActive   = true;

  // Update button to show fading
  const fadeBtn = document.getElementById('uniFadeBtn');
  if (fadeBtn) {
    fadeBtn.textContent  = '↓ Fading…';
    fadeBtn.style.color  = 'var(--orange)';
    fadeBtn.style.border = '1px solid var(--orange)';
  }

  if (vwbActiveEngine === 'organ') {
    // Organ — fade the abGain node
    if (typeof abGain === 'undefined' || !abGain) { _fadeCleanup(); return; }
    const startVol = abGain.gain.value;
    let step = 0;
    _fadeInterval = setInterval(() => {
      step++;
      abGain.gain.value = Math.max(0, startVol * (1 - step / steps));
      if (step >= steps) {
        if (typeof abStop === 'function') abStop();
        abGain.gain.value = startVol; // restore
        _fadeCleanup();
      }
    }, stepMs);

  } else if (vwbActiveEngine === 'midi') {
    // MIDI — fade via Tone.js destination
    let step = 0;
    let startDb = 0;
    try { startDb = (typeof Tone !== 'undefined') ? Tone.getDestination().volume.value : 0; } catch(e) {}
    _fadeInterval = setInterval(() => {
      step++;
      const pct = Math.max(0, 1 - step / steps);
      try {
        if (typeof Tone !== 'undefined') {
          Tone.getDestination().volume.value = pct <= 0 ? -Infinity : 20 * Math.log10(pct);
        }
      } catch(e) {}
      if (step >= steps) {
        if (typeof stopMidiPlay === 'function') stopMidiPlay();
        try { if (typeof Tone !== 'undefined') Tone.getDestination().volume.value = startDb; } catch(e) {}
        _fadeCleanup();
      }
    }, stepMs);

  } else {
    // Audio — fade the master mGain node
    const startVol = mGain.gain.value;
    let step = 0;
    _fadeInterval = setInterval(() => {
      step++;
      mGain.gain.value = Math.max(0, startVol * (1 - step / steps));
      if (step >= steps) {
        doStop();
        mGain.gain.value = startVol; // restore after stop
        _fadeCleanup();
      }
    }, stepMs);
  }
}

function _fadeCleanup() {
  clearInterval(_fadeInterval);
  _fadeInterval = null;
  _fadeActive   = false;
  const fadeBtn = document.getElementById('uniFadeBtn');
  if (fadeBtn) {
    fadeBtn.textContent  = '↓ Fade';
    fadeBtn.style.color  = 'var(--text-dim)';
    fadeBtn.style.border = '1px solid var(--border)';
  }
  _uniUpdateTransportUI();
}

// ── Unified Seek ───────────────────────────────────────────────

function uniSeek(pct) {
  if (vwbActiveEngine === 'midi') {
    seekMidi(pct);
  } else {
    const dur = getDur();
    jumpTo((pct / 100) * dur);
  }
}

// ── Engine Selector UI ─────────────────────────────────────────

function _uniRenderEngineSelector() {
  const wrap = document.getElementById('uniEngineSelector');
  if (!wrap) return;

  const audioActive = vwbActiveEngine === 'audio';
  const midiActive  = vwbActiveEngine === 'midi';

  const btnBase = `font-family:'Outfit',sans-serif;font-size:.85rem;font-weight:600;
                   padding:.45rem 1.25rem;border-radius:8px;cursor:pointer;
                   transition:all .2s;border:2px solid;letter-spacing:.04em;`;

  wrap.innerHTML = `
    <div style="display:flex;align-items:center;gap:.5rem;">
      <span style="font-size:.72rem;color:var(--text-dim);text-transform:uppercase;
                   letter-spacing:.08em;font-weight:600;">Engine</span>
      <button onclick="setVwbEngine('audio')"
        style="${btnBase}
               background:${audioActive ? 'rgba(64,224,208,.15)' : 'none'};
               border-color:${audioActive ? 'var(--accent)' : 'var(--border)'};
               color:${audioActive ? 'var(--accent)' : 'var(--text-dim)'};">
        🎵 Audio
      </button>
      <button onclick="setVwbEngine('midi')"
        style="${btnBase}
               background:${midiActive ? 'rgba(255,136,68,.15)' : 'none'};
               border-color:${midiActive ? 'var(--orange)' : 'var(--border)'};
               color:${midiActive ? 'var(--orange)' : 'var(--text-dim)'};">
        🎹 MIDI
      </button>
    </div>`;
}

// ── Unified Section Cards ──────────────────────────────────────
// Always uses song.secs — same sections for both audio and MIDI.
// Jump routing is handled by queueSection which bridges to MIDI.

function uniRenderSections() {
  const wrap = document.getElementById('uniSecs');
  if (!wrap) return;

  if (!song.secs || !song.secs.length) {
    wrap.innerHTML = '';
    wrap.style.display = 'none';
    return;
  }

  wrap.style.display = 'flex';
  const isMidi = vwbActiveEngine === 'midi';

  wrap.innerHTML = song.secs.map((s, i) => {
    // For MIDI engine, highlight based on curSec which queueSection sets
    const a = i === curSec;
    const q = i === qSec;
    const hasLoopFlag = s.loop === true;
    const isLooping   = a && (isMidi ? midiSecLoopOn : secLoopOn) && hasLoopFlag;
    const loopInd = isLooping
      ? '<span class="sec-loop-indicator on">🔁 LOOPING</span>'
      : (hasLoopFlag ? '<span class="sec-loop-indicator" style="opacity:.45">🔁 preset</span>' : '');
    const secDisplayName = (s.type === 'Custom' && s.customLabel) ? s.customLabel : s.type;
    const accentColor = isMidi ? 'var(--orange)' : 'var(--accent)';
    const accentBg    = isMidi ? 'rgba(255,136,68,.15)' : 'rgba(64,224,208,.15)';
    return `
      <div class="p-sec${a ? ' act' : ''}${q ? ' q' : ''}"
           onclick="uniJumpSection(${i})"
           style="${a ? ('border-color:' + accentColor + ';') : ''}">
        <span class="s-hk">${i + 1}</span>
        <div class="s-inf">
          <h4>${secDisplayName}${s.label ? ' — ' + s.label : ''}</h4>
          <div class="s-meas">Bars ${s.sb} – ${s.eb} ${loopInd}</div>
        </div>
        <button style="font-size:.65rem;padding:.15rem .35rem;border-radius:4px;
                       border:1px solid ${hasLoopFlag ? accentColor : 'var(--border)'};
                       background:${hasLoopFlag ? accentBg : 'none'};
                       color:${hasLoopFlag ? accentColor : 'var(--text-dim)'};
                       cursor:pointer;margin-left:auto;flex-shrink:0"
                onclick="event.stopPropagation();toggleSecLoopFlag(${i})">🔁</button>
        <div class="s-qlbl">NEXT ▶</div>
      </div>`;
  }).join('');
}

// ── Unified Timeline ───────────────────────────────────────────

function uniRenderTimeline() {
  const c = document.getElementById('uniTimeline');
  if (!c) return;
  c.innerHTML = '';

  if (!song.secs || !song.secs.length) return;

  if (vwbActiveEngine === 'midi') {
    const active = getMidiActive();
    const dur = active ? (active.duration || 0) : 0;
    if (dur <= 0) return;
    song.secs.forEach((s, i) => {
      const st = (typeof midiBar2Time === 'function') ? midiBar2Time(s.sb) : 0;
      const et = (typeof midiBar2Time === 'function') ? midiBar2Time(s.eb + 1) : 0;
      const wp = ((et - st) / dur) * 100;
      const label = (s.type === 'Custom' && s.customLabel) ? s.customLabel : s.type;
      c.innerHTML += `<div class="tl-sec${i === curSec ? ' on' : ''}"
        style="width:${Math.min(wp, 100)}%;position:relative"
        onclick="event.stopPropagation();uniJumpSection(${i})">${label}</div>`;
    });
    return;
  }

  // Audio timeline
  const d = getDur();
  if (d <= 0) return;
  song.secs.forEach((s, i) => {
    const st = bar2time(s.sb), et = bar2time(s.eb + 1);
    const wp = ((et - st) / d) * 100;
    const tlLabel = (s.type === 'Custom' && s.customLabel) ? s.customLabel : s.type;
    c.innerHTML += `<div class="tl-sec${i === curSec ? ' on' : ''}"
      style="width:${Math.min(wp, 100)}%;position:relative"
      onclick="event.stopPropagation();uniJumpSection(${i})">${tlLabel}</div>`;
  });
}

// ── Progress Bar Update ────────────────────────────────────────

function uniUpdateProgress() {
  let t = 0, dur = 0;

  if (vwbActiveEngine === 'midi') {
    t   = (typeof getMidiCurrentTime === 'function') ? getMidiCurrentTime() : 0;
    const active = getMidiActive();
    dur = active ? (active.duration || 0) : 0;
  } else {
    t   = getCurTime();
    dur = getDur();
  }

  const pct  = dur > 0 ? (t / dur) * 100 : 0;
  const prog = document.getElementById('uniProgFill');
  if (prog) prog.style.width = pct + '%';

  const timeEl = document.getElementById('uniTimeDisplay');
  if (timeEl) timeEl.textContent = fmt(t) + ' / ' + fmt(dur);

  // Bar display
  let bar = 1;
  if (vwbActiveEngine === 'midi' && typeof midiTime2Bar === 'function') {
    bar = midiTime2Bar(t * ((midiTempoPct || 100) / 100));
  } else {
    bar = time2bar(t);
  }
  const barEl = document.getElementById('uniBarDisplay');
  if (barEl) barEl.textContent = bar;
}

// ── MIDI Controls Visibility ───────────────────────────────────

function uniUpdateMidiControls() {
  const midiCtrl = document.getElementById('uniMidiControls');
  if (midiCtrl) midiCtrl.style.display = vwbActiveEngine === 'midi' ? 'flex' : 'none';
}

// ── Transport Button Sync ──────────────────────────────────────

function _uniUpdateTransportUI() {
  const isPlaying = vwbActiveEngine === 'midi' ? midiPlaying : playing;
  const playBtn   = document.getElementById('uniPlayBtn');
  if (playBtn) {
    playBtn.innerHTML = isPlaying ? '⏸' : '▶';
    playBtn.classList.toggle('on', isPlaying);
  }

  const loopBtn = document.getElementById('uniSecLoopBtn');
  if (loopBtn) {
    const loopOn = vwbActiveEngine === 'midi' ? midiSecLoopOn : secLoopOn;
    loopBtn.classList.toggle('on', loopOn);
  }

  uniRenderSections();
  uniRenderTimeline();
  uniUpdateMidiControls();
  _uniRenderEngineSelector();
}

// ── Audio Engine Tick Hook ─────────────────────────────────────

function uniOnAudioTick() {
  if (vwbActiveEngine !== 'audio') return;
  uniUpdateProgress();
  const tlSecs = document.getElementById('uniTimeline');
  if (tlSecs) {
    tlSecs.querySelectorAll('.tl-sec').forEach((e, i) => e.classList.toggle('on', i === curSec));
  }
}

// ── MIDI Engine Tick Hook ──────────────────────────────────────

function uniOnMidiTick() {
  if (vwbActiveEngine !== 'midi') return;
  uniUpdateProgress();
  const tlSecs = document.getElementById('uniTimeline');
  if (tlSecs) {
    tlSecs.querySelectorAll('.tl-sec').forEach((e, i) => e.classList.toggle('on', i === curSec));
  }
  // Highlight active section card using curSec
  const wrap = document.getElementById('uniSecs');
  if (wrap) {
    wrap.querySelectorAll('.p-sec').forEach((el, i) => {
      el.classList.toggle('act', i === curSec);
    });
  }
}

// ── Full Perform View Refresh ──────────────────────────────────

function uniRefreshPerfView() {
  _uniUpdateTransportUI();
  uniUpdateProgress();
  uniUpdateMidiControls();
  setVwbEngine(vwbActiveEngine, false);
  const perfTempo = document.getElementById('pTempo');
  if (perfTempo) {
    const bpm = (vwbActiveEngine === 'midi' && typeof midiBpm !== 'undefined')
      ? midiBpm : (song.tempo || 72);
    perfTempo.textContent = bpm + ' BPM';
  }
  // Organ panel visibility
  const abPanel = document.getElementById('abPerfPanel');
  if (abPanel) abPanel.style.display = vwbActiveEngine === 'organ' ? '' : 'none';
  if (typeof renderArmorBearerPerform === 'function') renderArmorBearerPerform();
}
