// ─────────────────────────────────────────────────────────────
//  VWB News Panel  —  js/vwb-news.js
//  Fetches content from your Netlify-hosted JSON feed and
//  renders it in the What's New tab. The bell badge pulses
//  until the user opens the panel, then clears until the
//  next time you publish new content.
// ─────────────────────────────────────────────────────────────

const VWB_NEWS_FEED_URL = 'https://virtualworshipband.netlify.app/vwb-news.json';
const VWB_NEWS_SEEN_KEY = 'vwb_news_last_seen_id';

// ── Entry point — called from DOMContentLoaded in index.html ──
function vwbNewsInit() {
  vwbNewsFetch();
}

// ── Fetch the JSON feed ───────────────────────────────────────
async function vwbNewsFetch() {
  try {
    const res = await fetch(VWB_NEWS_FEED_URL + '?t=' + Date.now());
    if (!res.ok) throw new Error('Network response was not ok');
    const data = await res.json();
    vwbNewsRender(data);
    vwbNewsCheckBadge(data);
  } catch (err) {
    // Silently fail — no internet or feed not yet deployed
    const el = document.getElementById('newsContent');
    if (el) el.innerHTML = '<div class="news-empty">Unable to load updates right now.<br>Check your internet connection or try again later.</div>';
  }
}

// ── Check if there is unseen content and show the badge ──────
function vwbNewsCheckBadge(data) {
  const lastSeenId = localStorage.getItem(VWB_NEWS_SEEN_KEY) || '';
  const latestId = data.latest_id || '';
  const dot = document.getElementById('newsBellDot');
  if (!dot) return;
  if (latestId && latestId !== lastSeenId) {
    dot.classList.add('active');
  } else {
    dot.classList.remove('active');
  }
}

// ── Called when the user clicks the What's New tab ───────────
function vwbNewsDismissBadge(data) {
  const dot = document.getElementById('newsBellDot');
  if (dot) dot.classList.remove('active');
  if (data && data.latest_id) {
    localStorage.setItem(VWB_NEWS_SEEN_KEY, data.latest_id);
  }
}

// ── Render the full panel from JSON data ─────────────────────
let _vwbNewsData = null;

function vwbNewsRender(data) {
  _vwbNewsData = data;
  const el = document.getElementById('newsContent');
  if (!el) return;

  let html = '';

  // Updated timestamp
  if (data.updated) {
    html += `<div class="news-updated">Last updated: ${data.updated}</div>`;
  }

  // ── Featured card ──
  if (data.featured) {
    const f = data.featured;
    html += `
      <div class="news-featured">
        <div class="news-featured-img">
          <div class="news-feat-icon">${f.icon || '🎵'}</div>
          <div class="news-feat-text">
            <div class="news-feat-eyebrow">${escHtml(f.eyebrow || '')}</div>
            <div class="news-feat-title">${escHtml(f.title)}</div>
            ${f.subtitle ? `<div class="news-feat-sub">${escHtml(f.subtitle)}</div>` : ''}
          </div>
          ${f.new ? '<span class="news-new-pill">Just Released</span>' : ''}
        </div>
        <div class="news-featured-body">
          <div class="news-featured-desc">${f.description}</div>
          ${f.cta_label && f.cta_url ? `<a class="news-cta-btn" href="#" onclick="vwbNewsOpenLink('${escHtml(f.cta_url)}');return false;">${escHtml(f.cta_label)} →</a>` : ''}
        </div>
      </div>`;
  }

  // ── Tips ──
  if (data.tips && data.tips.length > 0) {
    html += '<div class="news-section-label">Tips &amp; Tricks</div>';
    html += '<div class="news-tips-grid">';
    data.tips.forEach(tip => {
      html += `
        <div class="news-tip-card">
          <div class="news-tip-icon">${tip.icon || '💡'}</div>
          <div class="news-tip-title">${escHtml(tip.title)}</div>
          <div class="news-tip-body">${escHtml(tip.body)}</div>
        </div>`;
    });
    html += '</div>';
  }

  // ── Announcements ──
  if (data.announcements && data.announcements.length > 0) {
    html += '<div class="news-section-label">Announcements</div>';
    data.announcements.forEach(ann => {
      html += `
        <div class="news-announce-card">
          <div class="news-announce-icon">${ann.icon || '📢'}</div>
          <div>
            <div class="news-announce-title">${escHtml(ann.title)}</div>
            <div class="news-announce-sub">${escHtml(ann.body)}</div>
          </div>
          ${ann.link_label && ann.link_url ? `<a class="news-announce-link" href="#" onclick="vwbNewsOpenLink('${escHtml(ann.link_url)}');return false;">${escHtml(ann.link_label)} →</a>` : ''}
        </div>`;
    });
  }

  if (!data.featured && (!data.tips || data.tips.length === 0) && (!data.announcements || data.announcements.length === 0)) {
    html = '<div class="news-empty">No updates yet — check back soon!</div>';
  }

  el.innerHTML = html;
}

// ── Open external link via Electron shell ────────────────────
function vwbNewsOpenLink(url) {
  if (window.vwb && window.vwb.openExternal) {
    window.vwb.openExternal(url);
  } else {
    window.open(url, '_blank');
  }
}

// ── Hook into the existing goView function ───────────────────
//  Wraps the original so we can dismiss the badge when they
//  navigate to the news tab without touching other modules.
const _vwbOrigGoView = typeof goView !== 'undefined' ? goView : null;

document.addEventListener('DOMContentLoaded', () => {
  // Patch goView after all scripts load
  const originalGoView = window.goView;
  if (typeof originalGoView === 'function') {
    window.goView = function(view) {
      originalGoView(view);
      if (view === 'news' && _vwbNewsData) {
        vwbNewsDismissBadge(_vwbNewsData);
      }
    };
  }
});

// ── Utility ──────────────────────────────────────────────────
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
