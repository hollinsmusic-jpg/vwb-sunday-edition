// ═══════════════════════════════════════════════════════════════
//  Virtual Worship Band — Remote Bridge & License
//  VWB Remote broadcast, remoteAction handler, QR code,
//  and Lemon Squeezy license validation.
//  Depends on: state.js, audio-engine.js
// ═══════════════════════════════════════════════════════════════

// ── Remote Bridge ──────────────────────────────────────────────

let remoteInfo       = null;
let remotePanelOpen  = false;
let remoteStateTimer = null;
let remoteFading     = false;
let remoteFadeTimer  = null;

function toggleRemotePanel() {
  remotePanelOpen = !remotePanelOpen;
  const body  = document.getElementById('remotePanelBody');
  const arrow = document.getElementById('remoteToggleArrow');
  const hint  = document.getElementById('remotePanelHint');
  if (body)  body.style.display   = remotePanelOpen ? 'block' : 'none';
  if (arrow) arrow.style.transform = remotePanelOpen ? 'rotate(90deg)' : '';
  if (hint)  hint.textContent = remotePanelOpen ? 'Click to collapse' : 'Click to expand';
  if (remotePanelOpen) refreshRemoteInfo();
}

async function refreshRemoteInfo() {
  try {
    remoteInfo = await window.vwb.remoteGetInfo();
    const urlEl = document.getElementById('remoteUrl');
    if (urlEl) urlEl.textContent = remoteInfo.url;
    drawQRCode(remoteInfo.url);
  } catch(e) { console.log('Remote info error:', e); }
}

function drawQRCode(url) {
  const canvas = document.getElementById('qrCanvas');
  if (!canvas) return;
  const ctx  = canvas.getContext('2d');
  const size = 150;
  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, size, size);
  const img   = new Image();
  img.onload  = () => { ctx.fillStyle='white'; ctx.fillRect(0,0,size,size); ctx.drawImage(img,0,0,size,size); };
  img.onerror = () => {
    ctx.fillStyle = '#0a0e14'; ctx.fillRect(0, 0, size, size);
    ctx.fillStyle = '#40E0D0'; ctx.font = 'bold 11px monospace'; ctx.textAlign = 'center';
    ctx.fillText('Scan URL below', size/2, size/2 - 6);
    ctx.font = '9px monospace'; ctx.fillStyle = '#8892a4';
    const parts = url.replace('http://','').split(':');
    ctx.fillText(parts[0], size/2, size/2 + 10);
    ctx.fillText(':' + (parts[1]||'7878'), size/2, size/2 + 24);
  };
  img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' + encodeURIComponent(url) + '&bgcolor=ffffff&color=0a0e14&margin=2';
}

function broadcastRemoteState() {
  if (!window.vwb || !window.vwb.remoteStateUpdate) return;
  try {
    const isMidi    = typeof vwbActiveEngine !== 'undefined' && vwbActiveEngine === 'midi';
    const isPlaying = isMidi ? (typeof midiPlaying !== 'undefined' && midiPlaying) : playing;

    const secs   = song.secs || [];
    const curIdx = typeof curSec !== 'undefined' ? curSec : -1;
    let curSecName = '—';
    if (curIdx >= 0 && secs[curIdx]) curSecName = secs[curIdx].label || secs[curIdx].type || 'Section ' + (curIdx + 1);

    // Progress — from whichever engine is active
    let progress = 0, elapsed = 0, duration = 0;
    if (isMidi) {
      const mt  = (typeof getMidiCurrentTime === 'function') ? getMidiCurrentTime() : 0;
      const dur = (typeof midiDuration !== 'undefined' && typeof midiTempoPct !== 'undefined')
        ? midiDuration / (midiTempoPct / 100) : 0;
      elapsed  = mt;
      duration = dur;
      if (dur > 0) progress = Math.min(100, (mt / dur) * 100);
    } else {
      elapsed  = isPlaying ? Math.max(0, AC.currentTime - startAt) : pauseAt;
      duration = getDur();
      if (duration > 0) progress = Math.min(100, (elapsed / duration) * 100);
    }

    let nextSongTitle = '';
    if (typeof svcCues !== 'undefined' && typeof svcCurIdx !== 'undefined') {
      for (let i = svcCurIdx + 1; i < svcCues.length; i++) {
        if (svcCues[i] && svcCues[i].type === 'song') { nextSongTitle = svcCues[i].title || ''; break; }
      }
    }

    const stemMutes = {};
    SK.forEach(k => { stemMutes[k] = S[k] ? (S[k].muted || false) : false; });

    const state = {
      playing: isPlaying,
      panicActive,
      engine: isMidi ? 'midi' : 'audio',
      songTitle: song.title || '',
      nextSong: nextSongTitle,
      currentSection: curSecName,
      currentSectionIdx: curIdx,
      sections: secs.map(s => ({ type: s.type || '', label: s.label || s.type || '' })),
      progress: Math.round(progress),
      duration,
      elapsed,
      masterVol: Math.round((mGain.gain.value || 0.8) * 100),
      secLoop: (isMidi ? (typeof midiSecLoopOn !== 'undefined' && midiSecLoopOn) : secLoopOn) || false,
      loopOn: typeof loopPlaying !== 'undefined' ? loopPlaying : false,
      loops: loopLibrary.map(lp => ({ fn: lp.fn || '', duration: lp.buf ? lp.buf.duration : 0, vol: lp.vol || 80 })),
      activeLoopIdx: typeof activeLoopIdx !== 'undefined' ? activeLoopIdx : -1,
      midiFiles: midiPlaylist.map(m => ({ fn: m.fileName || '', duration: m.duration || 0 })),
      midiActiveIdx, midiPlaying,
      setlist: setlist.map(s => ({ title: s.title || '', tempo: s.tempo || '', ts: s.ts || '4/4' })),
      activeSongTitle: song.title || '',
      stemMutes,
      auxMuted: auxMasterMuted || false,
      fading: remoteFading || false
    };
    window.vwb.remoteStateUpdate(state);
  } catch(e) {}
}

function remoteAction(msg) {
  const a = msg.action;
  try {
    if      (a === 'playPause')     { if (typeof uniTogglePlay === 'function') uniTogglePlay(); else togglePlay(); }
    else if (a === 'stop')          { if (typeof uniStop === 'function') uniStop(); else doStop(); }
    else if (a === 'panic')         panicActive ? panicRecover() : panicEngage();
    else if (a === 'nextSec') {
      const ni = Math.min(song.secs.length - 1, (curSec < 0 ? 0 : curSec) + 1);
      if (ni >= 0) queueSection(ni);
    }
    else if (a === 'prevSec') {
      const pi = Math.max(0, (curSec < 0 ? 0 : curSec) - 1);
      queueSection(pi);
    }
    else if (a === 'jumpToSection') queueSection(msg.idx);
    else if (a === 'secLoop') {
      if (typeof uniToggleSecLoop === 'function') uniToggleSecLoop();
      else { secLoopOn = !secLoopOn; updatePerfLoopUI(); }
    }
    else if (a === 'loopToggle')    toggleLoop();
    else if (a === 'setActiveLoop') switchLoop(msg.idx);
    else if (a === 'setLoopVol')    { if (loopLibrary[msg.idx]) { loopLibrary[msg.idx].vol = msg.value; applyLoopVol(); } }
    else if (a === 'midiPlay')      toggleMidiPlay();
    else if (a === 'midiNext')      { if (midiPlaylist.length > 0) selectMidiFile((midiActiveIdx + 1) % midiPlaylist.length); }
    else if (a === 'midiSelect')    selectMidiFile(msg.idx);
    else if (a === 'setVol' && msg.volType === 'master') {
      if (typeof setMasterVol === 'function') setMasterVol(msg.value);
      else mGain.gain.value = msg.value / 100;
    }
    else if (a === 'stemMute')      { if (S[msg.stem]) { S[msg.stem].muted = !S[msg.stem].muted; applySoloMute(); } }
    else if (a === 'auxMute')       { auxMasterMuted = !auxMasterMuted; auxMasterGain.gain.value = auxMasterMuted ? 0 : auxMasterVol / 100; renderMixer(); }
    else if (a === 'fadeOut')       remoteDoFade();
    else if (a === 'loadSong')      { if (setlist[msg.idx]) loadSongData(setlist[msg.idx]); }
    else if (a === 'seekTo') {
      const isMidi = typeof vwbActiveEngine !== 'undefined' && vwbActiveEngine === 'midi';
      if (isMidi) {
        if (typeof seekMidi === 'function') seekMidi(msg.pct * 100);
      } else {
        const dur = getDur();
        if (dur > 0) jumpTo(msg.pct * dur);
      }
    }
    setTimeout(broadcastRemoteState, 150);
  } catch(e) { console.log('Remote action error:', e); }
}

function remoteDoFade() {
  if (!playing || remoteFading) return;
  remoteFading = true;
  const fadeDuration = 4, steps = 40;
  const stepTime = (fadeDuration * 1000) / steps;
  const startVol = mGain.gain.value;
  let step = 0;
  remoteFadeTimer = setInterval(() => {
    step++;
    mGain.gain.value = Math.max(0, startVol * (1 - step / steps));
    if (step >= steps) {
      clearInterval(remoteFadeTimer);
      if (typeof uniStop === 'function') uniStop(); else doStop();
      mGain.gain.value = startVol;
      remoteFading = false;
      broadcastRemoteState();
    }
  }, stepTime);
}

function startRemoteBroadcast() {
  if (remoteStateTimer) clearInterval(remoteStateTimer);
  remoteStateTimer = setInterval(broadcastRemoteState, 1000);
}

async function initRemote() {
  try {
    remoteInfo = await window.vwb.remoteGetInfo();
    const urlEl = document.getElementById('remoteUrl');
    if (urlEl) urlEl.textContent = remoteInfo.url;
    startRemoteBroadcast();
  } catch(e) { console.log('Remote init:', e); }
}

setTimeout(initRemote, 2000);

// ── License System ─────────────────────────────────────────────

const LS_API_KEY       = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI5NGQ1OWNlZi1kYmI4LTRlYTUtYjE3OC1kMjU0MGZjZDY5MTkiLCJqdGkiOiJhNjAxMGEwZTZhN2Q3NWVjZDJhNjg3M2E4YTMyOTg4MzUwZjEwNDNjMTliNjJlMGM0OWMyOGZmYzA0NTljOGE5MDBjNGEwOTliMmUxOTQ2NCIsImlhdCI6MTc4MDY2ODE3OC42MTI4MTEsIm5iZiI6MTc4MDY2ODE3OC42MTI4MTQsImV4cCI6MjExNDI5NDQwMC4wMzcxNzYsInN1YiI6IjczMDc5MDEiLCJzY29wZXMiOltdfQ.kuscrjL01tTaE2SlwZ4cEJgJgOnSc93xXaGW-oO23ofLZWj20C0aykuFnJ1DgewESwE8ssTaGRe6v-XXt5kkgUcaBCYkDfIbrlbADERKpt9LEOoztOI7sSRlkDaScgrXJFJpcJtgGXWkVsneSSTb6Bar6VDZPaUbAgJegOhGfsfoVn-ZvkDwCyBZSX3Z7eXCxOT21DlVhxAalGWoVjSHzPLyev451PRy6A_I9AwAasLRFD1iHzfkYxMZqSrZD7Cn2mnfPi_kxtN-QvQQUEcCCY6V5B5J6tCoJ9Fi-ODLjpKcHZsL7pMDsZVV9yYL91-MKjr0m4lWomrc_Oz3GnItkDGHBlHAI039GBuuY-xc9XFptI-rrol39A04DULmA5ctL_VI-jjY_ricFc7-FFvgY_ljiwKVnTBmmKQAUXd5FLNHUCSDc7OBTfCGTCsxBDgSz16BnjVVuT9aCqpSoggAoc53IYVHVpkYmzk1Gn70O3ZkoWWlhtPGBVpBCGEYvBGN5A0ky3ldXFcC9Lvf2-gu5LgSwqfB1q1so2xEzOHYe7BnrjlwBc9r476TON06mVqw2zoHlONha1KQ77hDHkMN8lP4kQalUiXBiAL72Ty7rWAoRqRTxC76SbCECuTDAucSipIYbJ0DK4uqUTQGU8bKdzNlYkUUes6Ez_dbWFgPwxo';
const LS_STORE_ID      = '395278';
const LICENSE_KEY      = 'vwb_license_key';
const LICENSE_INSTANCE = 'vwb_license_instance';

async function checkLicenseActivation() {
  try {
    const savedKey = await window.vwb.loadJson('license');
    if (!savedKey.success || !savedKey.data || !savedKey.data.key) return false;
    const { key, instanceId } = savedKey.data;
    if (!key || !instanceId) return false;
    return await verifyLicenseKey(key, instanceId);
  } catch(e) {
    try {
      const savedKey = await window.vwb.loadJson('license');
      return savedKey.success && savedKey.data && savedKey.data.key;
    } catch(e2) { return false; }
  }
}

async function verifyLicenseKey(key, instanceId) {
  try {
    const resp = await fetch('https://api.lemonsqueezy.com/v1/licenses/validate', {
      method: 'POST',
      headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ license_key: key, instance_id: instanceId })
    });
    if (!resp.ok) return false;
    const data = await resp.json();
    return data.valid === true;
  } catch(e) { return true; } // allow offline use if already activated
}

async function activateLicense() {
  const keyInput = document.getElementById('licenseKeyInput');
  const btn      = document.getElementById('licenseActivateBtn');
  const errEl    = document.getElementById('licenseError');
  const sucEl    = document.getElementById('licenseSuccess');
  const key      = (keyInput.value || '').trim();
  if (!key) { errEl.textContent = 'Please enter your license key.'; return; }

  // Owner bypass
  if (key === 'HMPI-OWNER-2026' || key === 'HMPI-DEV-BYPASS') {
    await window.vwb.saveJson('license', { key, instanceId: 'owner-bypass', activatedAt: new Date().toISOString() });
    sucEl.textContent = '✓ Owner access granted. Loading VWB...';
    btn.textContent   = '✓ Activated!';
    setTimeout(() => showMainApp(), 1000);
    return;
  }

  errEl.textContent = ''; sucEl.textContent = '';
  btn.disabled = true; btn.textContent = 'Activating...';

  try {
    const resp = await fetch('https://api.lemonsqueezy.com/v1/licenses/activate', {
      method: 'POST',
      headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ license_key: key, instance_name: 'VWB-' + (navigator.platform || 'Desktop') })
    });
    const data = await resp.json();
    if (resp.ok && data.activated) {
      await window.vwb.saveJson('license', {
        key, instanceId: data.instance ? data.instance.id : '', activatedAt: new Date().toISOString()
      });
      sucEl.textContent = '✓ Activated successfully! Loading VWB...';
      btn.textContent   = '✓ Activated!';
      setTimeout(() => showMainApp(), 1500);
    } else {
      const errMsg = data.error || (data.errors && data.errors[0] && data.errors[0].detail) || '';
      if (errMsg.toLowerCase().includes('limit')) {
        errEl.textContent = 'Activation limit reached. This key is already active on the maximum number of computers. Contact hollinsmusic@gmail.com for help.';
      } else if (errMsg.toLowerCase().includes('invalid') || errMsg.toLowerCase().includes('not found')) {
        errEl.textContent = 'Invalid license key. Please check your purchase email and try again.';
      } else {
        errEl.textContent = 'Activation failed: ' + (errMsg || 'Unknown error. Please try again or contact support.');
      }
      btn.disabled = false; btn.textContent = 'Activate VWB';
    }
  } catch(e) {
    errEl.textContent = 'Network error. Please check your internet connection and try again.';
    btn.disabled = false; btn.textContent = 'Activate VWB';
  }
}

// ── App Init ───────────────────────────────────────────────────

async function initApp() {
  const isActivated = await checkLicenseActivation();
  if (!isActivated) {
    document.getElementById('splash').classList.add('hidden');
    setTimeout(() => { document.getElementById('splash').style.display = 'none'; }, 600);
    document.getElementById('licenseScreen').style.display = 'flex';
    return;
  }
  showMainApp();
}

async function showMainApp() {
  document.getElementById('splash').classList.add('hidden');
  document.getElementById('licenseScreen').style.display = 'none';
  setTimeout(() => { document.getElementById('splash').style.display = 'none'; }, 600);
  document.getElementById('app').style.display = 'block';
  if (AC.state === 'suspended') AC.resume();
  renderStems(); renderAuxPanel(); renderSections(); renderRouting();
  renderLoopLibrary(); updMInfo(); initMiniBeats(); initScrubButtons(); renderMrcGrid();
  if (typeof renderProcessorUI === 'function') renderProcessorUI();

  try {
    const savedLoopVol = localStorage.getItem('vwb_loopVol');
    if (savedLoopVol !== null) {
      const v = parseInt(savedLoopVol);
      loopGain.gain.value = v / 100;
      document.querySelectorAll('.loop-vol-slider').forEach(el => { el.value = v; });
      const pct = document.getElementById('loopPct');
      if (pct) pct.textContent = v + '%';
    }
  } catch(e) {}

  loadCrossfadeSettings();
  initMidi().then(() => { refreshMrcInputs(); });
  await loadMrcMappings();

  // Fresh start — nothing auto-loads.
  // User opens what they need via File > Open Session or File > Open Recent.

  await loadSvcCues();
  initSvcMrcFunctions();

  document.getElementById('songTempo').addEventListener('change', () => {
    song.tempo = parseInt(document.getElementById('songTempo').value) || 72;
    updMInfo(); initMiniBeats();
  });
  document.getElementById('songTimeSig').addEventListener('change', () => {
    song.ts = document.getElementById('songTimeSig').value;
    updMInfo(); initMiniBeats();
  });
}
